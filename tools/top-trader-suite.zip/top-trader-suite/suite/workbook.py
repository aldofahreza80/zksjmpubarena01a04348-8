"""Write the single audit workbook: Ringkasan, Gabungan, one raw sheet per provider, and Log."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import math
from pathlib import Path
import platform
import re
import subprocess
import sys

from openpyxl import Workbook
from openpyxl import __version__ as OPENPYXL_VERSION
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties

from suite import __version__
from suite.adapters import TEXT_COLUMNS
from suite.combine import CombinedRow, SourceData
from suite.providers import ProviderSpec
from suite.runner import RunResult
from suite.summary import LIST_LIMIT, TOP_N, Summary

FONT_NAME = "Arial"
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
USD_FORMAT = "#,##0.00"
HEADER_FILL = PatternFill("solid", start_color="FF404040", end_color="FF404040")
SECTION_FILL = PatternFill("solid", start_color="FFD9D9D9", end_color="FFD9D9D9")
INPUT_FILL = PatternFill("solid", start_color="FFFFFF00", end_color="FFFFFF00")
FLAG_FILL = PatternFill("solid", start_color="FFFFE0B2", end_color="FFFFE0B2")
STATUS_TEXT = {"ok": "ok", "failed": "gagal", "timeout": "timeout", "error": "error", "skipped": "dilewati", "pending": "belum jalan"}


@dataclass
class RunInfo:
    mint: str
    snapshot: datetime
    spread_usd: float
    spread_pct: float  # fraction (0.25 = 25%)
    timeout: float
    raw_json: bool
    requested: list[str]  # provider labels


def safe_text(value: object) -> str:
    """Text for a cell: control characters removed, and never interpreted as a formula."""
    text = ILLEGAL_CHARACTERS_RE.sub("", str(value))[:32000]
    return "'" + text if text.startswith(FORMULA_PREFIXES) else text


def _font(bold: bool = False, italic: bool = False, color: str | None = None) -> Font:
    return Font(name=FONT_NAME, size=10, bold=bold, italic=italic, color=color)


def _put(ws, row: int, column: int, value, *, bold=False, italic=False, color=None, fill=None, fmt=None, wrap=False, formula=False):
    if isinstance(value, str) and not formula:
        value = safe_text(value)
    cell = ws.cell(row=row, column=column, value=value)
    cell.font = _font(bold, italic, color)
    if fill is not None:
        cell.fill = fill
    if fmt:
        cell.number_format = fmt
    if wrap:
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    return cell


def _header(ws, row: int, headers: list[str]) -> None:
    for column, text in enumerate(headers, start=1):
        _put(ws, row, column, text, bold=True, color="FFFFFFFF", fill=HEADER_FILL)


def _fmt_ts(value: datetime | None) -> str | None:
    return value.strftime("%Y-%m-%d %H:%M:%S") if value else None


def _raw_value(column: str, text: str):
    text = text.strip()
    if not text:
        return None
    if column in TEXT_COLUMNS:
        return text
    try:
        number = float(text)
    except ValueError:
        return text
    if not math.isfinite(number):
        return text
    if re.fullmatch(r"-?\d+", text) and len(text.lstrip("-")) < 16:
        return int(text)
    return number


def gabungan_columns(specs: list[ProviderSpec]) -> list[str]:
    return (
        ["wallet", "name", "n_sources", "sources"]
        + [f"rank_{s.key}" for s in specs]
        + [f"realized_{s.key}" for s in specs]
        + ["spread_usd", "spread_pct", "flag_spread", "only_in", "role_disagreement"]
        + [f"labels_{s.key}" for s in specs]
        + ["funded_by_gmgn"]
        + [f"sheet_row_{s.key}" for s in specs]
    )


class _Cursor:
    def __init__(self, ws) -> None:
        self.ws, self.row = ws, 1

    def blank(self, count: int = 1) -> None:
        self.row += count

    def title(self, text: str) -> None:
        _put(self.ws, self.row, 1, text, bold=True)
        self.ws.cell(row=self.row, column=1).font = Font(name=FONT_NAME, size=13, bold=True)
        self.row += 1

    def section(self, text: str, width: int = 10) -> None:
        for column in range(1, width + 1):
            _put(self.ws, self.row, column, text if column == 1 else None, bold=True, fill=SECTION_FILL)
        self.row += 1

    def kv(self, label: str, value, *, fmt=None, formula=False, input_cell=False) -> int:
        _put(self.ws, self.row, 1, label)
        _put(self.ws, self.row, 2, value, fmt=fmt, formula=formula, color="FF0000FF" if input_cell else None, fill=INPUT_FILL if input_cell else None)
        self.row += 1
        return self.row - 1

    def table(self, headers: list[str], rows: list[list], formats: dict[int, str] | None = None) -> None:
        _header(self.ws, self.row, headers)
        self.row += 1
        for values in rows:
            for column, value in enumerate(values, start=1):
                is_formula = isinstance(value, str) and value.startswith("=")
                _put(self.ws, self.row, column, value, fmt=(formats or {}).get(column), formula=is_formula)
            self.row += 1

    def note(self, text: str) -> None:
        _put(self.ws, self.row, 1, text)
        self.row += 1


def _autosize(ws, widths: dict[int, float] | None = None, default_max: float = 48) -> None:
    longest: dict[int, int] = {}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is not None:
                longest[cell.column] = max(longest.get(cell.column, 0), len(str(cell.value)))
    for column, length in longest.items():
        ws.column_dimensions[get_column_letter(column)].width = min(max(length + 2, 8), default_max)
    for column, width in (widths or {}).items():
        ws.column_dimensions[get_column_letter(column)].width = width


def _write_raw_sheet(ws, spec: ProviderSpec, result: RunResult | None, table) -> None:
    if table is None:
        _put(ws, 1, 1, f"Tidak ada data dari {spec.label}.", bold=True)
        status = STATUS_TEXT.get(result.status, result.status) if result else "tidak diminta"
        _put(ws, 2, 1, f"Status: {status}")
        if result and result.note:
            _put(ws, 3, 1, result.note)
        ws.column_dimensions["A"].width = 100
        return
    header, rows = table
    _header(ws, 1, header)
    for row_index, raw in enumerate(rows, start=2):
        for column_index, name in enumerate(header, start=1):
            text = raw[column_index - 1] if column_index - 1 < len(raw) else ""
            value = _raw_value(name, text)
            if value is None:
                continue
            fmt = USD_FORMAT if name.endswith("_usd") and not isinstance(value, str) else None
            _put(ws, row_index, column_index, value, fmt=fmt)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    _autosize(ws)


def write_workbook(
    path: Path,
    *,
    info: RunInfo,
    specs: list[ProviderSpec],
    results: list[RunResult],
    sources: list[SourceData],
    tables: dict[str, tuple[list[str], list[list[str]]]],
    combined: list[CombinedRow],
    summary: Summary,
    fingerprints: dict[str, list[tuple[str, str]]],
) -> None:
    wb = Workbook()
    ws_sum = wb.active
    ws_sum.title = "Ringkasan"
    ws_comb = wb.create_sheet("Gabungan")
    raw_sheets = {spec.key: wb.create_sheet(spec.label) for spec in specs}
    ws_log = wb.create_sheet("Log")

    columns = gabungan_columns(specs)
    col = {name: get_column_letter(index) for index, name in enumerate(columns, start=1)}
    last_row = len(combined) + 1  # last data row on Gabungan (header is row 1)
    result_by_key = {r.spec.key: r for r in results}
    ok_labels = [s.label for s in sources]
    n_ok = len(sources)

    usd_ref, pct_ref = _write_ringkasan(ws_sum, info, specs, results, sources, summary, col, last_row, n_ok)
    _write_gabungan(ws_comb, combined, specs, columns, col, usd_ref, pct_ref)
    for spec in specs:
        _write_raw_sheet(raw_sheets[spec.key], spec, result_by_key.get(spec.key), tables.get(spec.key))
    _write_log(ws_log, info, specs, results, fingerprints)
    wb.calculation = CalcProperties(fullCalcOnLoad=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def _write_ringkasan(ws, info, specs, results, sources, summary, col, last_row, n_ok):
    cur = _Cursor(ws)
    cur.title("Ringkasan run - audit lintas sumber")
    cur.blank()
    cur.kv("Mint", info.mint)
    cur.kv("Waktu snapshot (UTC)", _fmt_ts(info.snapshot))
    cur.kv("Sumber diminta", ", ".join(info.requested))
    cur.kv("Sumber berhasil", f"{n_ok} dari {len(info.requested)}" + (f" ({', '.join(s.label for s in sources)})" if sources else ""))
    cur.kv("Versi suite / Python", f"{__version__} / {platform.python_version()}")
    cur.blank()
    cur.section("Parameter (sel kuning boleh diubah; kolom flag_spread di sheet Gabungan dan hitungannya di sini ikut dihitung ulang)")
    usd_row = cur.kv("Ambang selisih realized (USD) >=", info.spread_usd, fmt=USD_FORMAT, input_cell=True)
    pct_row = cur.kv("Ambang selisih relatif >=", info.spread_pct, fmt="0.0%", input_cell=True)
    usd_ref, pct_ref = f"Ringkasan!$B${usd_row}", f"Ringkasan!$B${pct_row}"
    cur.note("Nilai awal berasal dari argumen --spread-usd dan --spread-pct. Selisih relatif = (tertinggi - terendah) / nilai absolut terbesar.")
    cur.blank()

    cur.section("Status per sumber")
    stat_by_key = {s.key: s for s in summary.sources}
    warn_by_key = {s.key: s.warnings for s in sources}
    rows = []
    for result in results:
        stats = stat_by_key.get(result.spec.key)
        note = result.note
        if warn_by_key.get(result.spec.key):
            note = "; ".join(filter(None, [note, *warn_by_key[result.spec.key][:3]]))
        lag = None
        if stats and stats.last_ts and result.ended:
            lag = round((result.ended - stats.last_ts).total_seconds() / 60, 1)
        last_cell = _fmt_ts(stats.last_ts) if stats and stats.last_ts else ("n/a (CSV tanpa kolom waktu)" if stats else None)
        rows.append([
            result.spec.label, STATUS_TEXT.get(result.status, result.status), stats.rows if stats else None,
            _fmt_ts(result.started), _fmt_ts(result.ended), round(result.elapsed, 1) if result.elapsed is not None else None,
            last_cell, lag, _fmt_ts(stats.first_ts) if stats and stats.first_ts else None, note,
        ])
    cur.table(
        ["Sumber", "Status", "Baris", "Mulai (UTC)", "Selesai (UTC)", "Durasi (dtk)", "Aktivitas terbaru di daftar (UTC)",
         "Selisih ke waktu selesai (menit)", "Aktivitas tertua di daftar (UTC)", "Catatan"],
        rows, {6: "0.0", 8: "0.0"},
    )
    cur.note("'Aktivitas terbaru/tertua' hanya dari wallet yang ada di daftar (bukan seluruh token), jadi menunjukkan perkiraan kasar keterlambatan data.")
    if summary.earliest_ts:
        cur.note(f"Aktivitas tertua yang terlihat: {_fmt_ts(summary.earliest_ts)} UTC (sekitar {summary.token_age_hours:.2f} jam sebelum snapshot).")
    cur.blank()

    if n_ok >= 2:
        n = last_row
        rng = lambda name: f"Gabungan!${col[name]}$2:${col[name]}${n}"
        cur.section("Cakupan wallet (rumus Excel atas sheet Gabungan)")
        cur.kv("Wallet unik (gabungan)", f"=COUNTA({rng('wallet')})", formula=True)
        cur.kv(f"Ada di semua {n_ok} sumber", f"=COUNTIF({rng('n_sources')},{n_ok})", formula=True)
        if n_ok == 3:
            cur.kv("Ada di tepat 2 sumber", f"=COUNTIF({rng('n_sources')},2)", formula=True)
        cur.kv("Hanya di 1 sumber", f"=COUNTIF({rng('n_sources')},1)", formula=True)
        for source in sources:
            cur.kv(f"   hanya di {source.label}", f'=COUNTIF({rng("only_in")},"{source.label}")', formula=True)
        for i, a in enumerate(sources):
            for b in sources[i + 1:]:
                cur.kv(f"Ada di {a.label} dan {b.label}", f'=COUNTIFS({rng("rank_" + a.key)},">0",{rng("rank_" + b.key)},">0")', formula=True)
        cur.kv("Wallet dengan selisih realized besar (flag_spread)", f'=COUNTIF({rng("flag_spread")},"yes")', formula=True)
        cur.kv("Wallet dengan perbedaan peran (role_disagreement)", f"=SUMPRODUCT(--(LEN({rng('role_disagreement')})>0))", formula=True)
        cur.blank()

        cur.section("Kecocokan realized PnL untuk wallet yang sama (dihitung oleh skrip Python, bukan rumus Excel)")
        pair_rows = []
        for pair in summary.pairs:
            pair_rows.append([
                f"{pair.a_label} vs {pair.b_label}", pair.shared,
                pair.median_abs_diff, pair.median_rel_diff,
                pair.spearman if pair.spearman is not None else "n/a (kurang dari 5 wallet bersama)",
                f"{pair.top_overlap}/{TOP_N}" if pair.top_overlap is not None else f"n/a (daftar < {TOP_N} baris)",
            ])
        cur.table(
            ["Pasangan", "Wallet bersama", "Median selisih (USD)", "Median selisih relatif", "Korelasi peringkat (Spearman)", f"Overlap top-{TOP_N}"],
            pair_rows, {3: USD_FORMAT, 4: "0.0%", 5: "0.00"},
        )
        cur.blank()

    cur.section("Catatan")
    for note in summary.notes:
        cur.note(note)
    cur.blank()
    cur.section("Kamus kolom sheet Gabungan")
    for line in [
        "rank_*: peringkat wallet di CSV provider itu (urutan realized PnL); kosong = wallet tidak ada di daftar provider itu.",
        "realized_*: realized_pnl_usd apa adanya dari provider; tidak ada rata-rata dan tidak ada penyatuan definisi.",
        "n_sources, spread_usd, spread_pct, flag_spread: rumus Excel. spread = realized tertinggi dikurangi terendah di antara provider yang memuat wallet.",
        "only_in: provider yang satu-satunya memuat wallet (hanya diisi bila >= 2 provider berhasil). Waspada: bisa karena daftar terpotong.",
        "role_disagreement: peran (dev, kol, smart_money, sniper, bundler, bot, arbitrage, pool_or_exchange) yang hanya dimiliki sebagian provider. "
        "Pemetaan label sederhana di suite/labels.py; hanya provider yang memberi label pada setidaknya satu wallet di run ini yang dibandingkan.",
        "sheet_row_*: nomor baris wallet di sheet mentah provider itu, untuk menelusuri angka ke sumbernya.",
    ]:
        cur.note(line)
    _autosize(ws, {1: 46, 2: 24})
    for column in range(3, 11):
        ws.column_dimensions[get_column_letter(column)].width = 22
    ws.column_dimensions["J"].width = 60
    return usd_ref, pct_ref


def _write_gabungan(ws, combined, specs, columns, col, usd_ref, pct_ref):
    _header(ws, 1, columns)
    first_rank, last_rank = col[f"rank_{specs[0].key}"], col[f"rank_{specs[-1].key}"]
    first_real, last_real = col[f"realized_{specs[0].key}"], col[f"realized_{specs[-1].key}"]
    index = {name: position for position, name in enumerate(columns, start=1)}
    for offset, item in enumerate(combined):
        r = offset + 2
        real = f"{first_real}{r}:{last_real}{r}"
        spread, pct = f"{col['spread_usd']}{r}", f"{col['spread_pct']}{r}"
        _put(ws, r, index["wallet"], item.wallet)
        _put(ws, r, index["name"], item.name)
        _put(ws, r, index["n_sources"], f"=COUNT({first_rank}{r}:{last_rank}{r})", formula=True)
        _put(ws, r, index["sources"], item.sources_text)
        for spec in specs:
            row = item.rows.get(spec.key)
            _put(ws, r, index[f"rank_{spec.key}"], row.rank if row else None)
            _put(ws, r, index[f"realized_{spec.key}"], row.realized if row else None, fmt=USD_FORMAT)
            if row:
                labels = "; ".join(row.labels)
                if row.token_tags:
                    labels = (labels + " | " if labels else "") + "token: " + "; ".join(row.token_tags)
                _put(ws, r, index[f"labels_{spec.key}"], labels or None)
                _put(ws, r, index[f"sheet_row_{spec.key}"], row.sheet_row)
        _put(ws, r, index["spread_usd"], f'=IF(COUNT({real})>=2,MAX({real})-MIN({real}),"")', formula=True, fmt=USD_FORMAT)
        _put(
            ws, r, index["spread_pct"],
            f'=IF(ISNUMBER({spread}),IF(MAX(ABS(MAX({real})),ABS(MIN({real})))=0,"",{spread}/MAX(ABS(MAX({real})),ABS(MIN({real})))),"")',
            formula=True, fmt="0.0%",
        )
        _put(
            ws, r, index["flag_spread"],
            f'=IF(AND(ISNUMBER({spread}),ISNUMBER({pct})),IF(AND({spread}>={usd_ref},{pct}>={pct_ref}),"yes",""),"")',
            formula=True,
        )
        _put(ws, r, index["only_in"], item.only_in or None)
        _put(ws, r, index["role_disagreement"], item.role_disagreement or None)
        _put(ws, r, index["funded_by_gmgn"], item.rows["gmgn"].funded_by if "gmgn" in item.rows else None)
    last = len(combined) + 1
    ws.freeze_panes = "B2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}{last}"
    flag, role = col["flag_spread"], col["role_disagreement"]
    ws.conditional_formatting.add(f"{col['spread_usd']}2:{flag}{last}", FormulaRule(formula=[f'${flag}2="yes"'], fill=FLAG_FILL))
    ws.conditional_formatting.add(f"{role}2:{role}{last}", FormulaRule(formula=[f'LEN(${role}2)>0'], fill=FLAG_FILL))
    _autosize(ws, {1: 46, index["name"]: 22, index["sources"]: 26, index["role_disagreement"]: 38, index["funded_by_gmgn"]: 46})


def _write_log(ws, info, specs, results, fingerprints):
    cur = _Cursor(ws)
    cur.title("Log run")
    cur.blank()
    cur.section("Lingkungan dan parameter")
    cur.kv("Suite", __version__)
    cur.kv("Python", sys.version.split()[0])
    cur.kv("Sistem operasi", platform.platform())
    cur.kv("openpyxl", OPENPYXL_VERSION)
    cur.kv("Mint", info.mint)
    cur.kv("Snapshot (UTC)", _fmt_ts(info.snapshot))
    cur.kv("Batas waktu per sumber (detik)", info.timeout)
    cur.kv("Arsip raw JSON diminta", "ya" if info.raw_json else "tidak")
    cur.kv("Ambang awal selisih (USD / relatif)", f"{info.spread_usd:g} / {info.spread_pct:.0%}")
    cur.blank()
    cur.section("Proses per sumber (kunci API tidak pernah dicatat; setiap proses hanya menerima kuncinya sendiri)")
    rows = []
    for result in results:
        rows.append([
            result.spec.label, STATUS_TEXT.get(result.status, result.status), result.returncode,
            subprocess.list2cmdline(result.command) if result.command else None, str(result.cwd) if result.cwd else None,
            _fmt_ts(result.started), _fmt_ts(result.ended), round(result.elapsed, 1) if result.elapsed is not None else None,
            ", ".join(p.name for p in ([result.csv_path] if result.csv_path else []) + result.extra_files) or None, result.note or None,
        ])
    cur.table(["Sumber", "Status", "Kode keluar", "Perintah", "Folder kerja", "Mulai (UTC)", "Selesai (UTC)", "Durasi (dtk)", "Berkas", "Catatan"], rows, {8: "0.0"})
    cur.blank()
    cur.section("Keluaran proses (dipotong bila panjang)")
    for result in results:
        for stream, text in (("stdout", result.stdout), ("stderr", result.stderr)):
            if text.strip():
                _put(ws, cur.row, 1, f"{result.spec.label} {stream}", bold=True)
                _put(ws, cur.row, 2, text, wrap=True)
                cur.row += 1
    cur.blank()
    cur.section("Sidik jari kode (SHA-256, 16 karakter pertama) - untuk memastikan versi kode yang dijalankan")
    fp_rows = [[spec.label, name, digest] for spec in specs for name, digest in fingerprints.get(spec.key, [])]
    cur.table(["Sumber", "Berkas", "SHA-256"], fp_rows)
    _autosize(ws, {1: 34, 2: 90}, default_max=60)
    ws.column_dimensions["D"].width = 60
    ws.column_dimensions["E"].width = 50
