"""Put the providers side by side, wallet by wallet. Nothing is averaged or blended."""
from __future__ import annotations

from dataclasses import dataclass, field

from suite.labels import roles_of
from suite.model import Row


@dataclass
class SourceData:
    key: str
    label: str
    rows: list[Row]
    warnings: list[str] = field(default_factory=list)


@dataclass
class CombinedRow:
    wallet: str
    rows: dict[str, Row]  # provider key -> that provider's row
    n_sources: int
    sources_text: str
    name: str | None
    funded_by: str | None
    spread_usd: float | None
    spread_pct: float | None  # fraction (0.25 = 25%)
    flag_spread: bool
    only_in: str  # provider label when exactly one of >= 2 successful providers lists this wallet
    role_disagreement: str
    best_realized: float | None


def combine(sources: list[SourceData], *, spread_pct: float = 0.25, spread_usd: float = 10.0) -> list[CombinedRow]:
    by_wallet: dict[str, dict[str, Row]] = {}
    for source in sources:
        for row in source.rows:
            by_wallet.setdefault(row.wallet, {})[source.key] = row
    order = [source.key for source in sources]
    labels = {source.key: source.label for source in sources}
    # Only providers that label at least one wallet in this run can "disagree" about roles.
    label_capable = {source.key for source in sources if any(roles_of(row) for row in source.rows)}

    combined: list[CombinedRow] = []
    for wallet, rows in by_wallet.items():
        present = [key for key in order if key in rows]
        values = {key: rows[key].realized for key in present if rows[key].realized is not None}
        spread_value = pct_value = None
        if len(values) >= 2:
            high, low = max(values.values()), min(values.values())
            spread_value = high - low
            denominator = max(abs(high), abs(low))
            pct_value = spread_value / denominator if denominator > 0 else None
        flagged = spread_value is not None and pct_value is not None and spread_value >= spread_usd and pct_value >= spread_pct

        role_text = ""
        capable_present = [key for key in present if key in label_capable]
        if len(capable_present) >= 2:
            roles = {key: roles_of(rows[key]) for key in capable_present}
            parts = []
            for role in sorted(set().union(*roles.values())):
                holders = [labels[key] for key in capable_present if role in roles[key]]
                if len(holders) != len(capable_present):
                    parts.append(f"{role} (hanya {', '.join(holders)})")
            role_text = "; ".join(parts)

        name = next((rows[key].name for key in present if rows[key].name), None)
        funded_by = next((rows[key].funded_by for key in present if rows[key].funded_by), None)
        combined.append(
            CombinedRow(
                wallet=wallet,
                rows=rows,
                n_sources=len(present),
                sources_text=", ".join(labels[key] for key in present),
                name=name,
                funded_by=funded_by,
                spread_usd=spread_value,
                spread_pct=pct_value,
                flag_spread=flagged,
                only_in=labels[present[0]] if len(sources) >= 2 and len(present) == 1 else "",
                role_disagreement=role_text,
                best_realized=max(values.values()) if values else None,
            )
        )
    combined.sort(key=lambda item: (-item.n_sources, -(item.best_realized if item.best_realized is not None else float("-inf")), item.wallet))
    return combined
