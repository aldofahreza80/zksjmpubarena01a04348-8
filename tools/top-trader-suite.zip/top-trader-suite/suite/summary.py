"""Run-level numbers for the Ringkasan sheet (computed in Python, so documented as such in the workbook)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from itertools import combinations
import math
from statistics import median

from suite.combine import SourceData

LIST_LIMIT = 100  # every provider CLI returns at most this many traders
TOP_N = 10
MIN_PAIRS_FOR_RANK_CORRELATION = 5


@dataclass
class SourceStats:
    key: str
    label: str
    rows: int
    labeled_rows: int
    first_ts: datetime | None
    last_ts: datetime | None
    hit_limit: bool


@dataclass
class PairStats:
    a_label: str
    b_label: str
    shared: int
    median_abs_diff: float | None
    median_rel_diff: float | None
    spearman: float | None
    top_overlap: int | None  # wallets in both providers' top TOP_N, None when either list is shorter than TOP_N


@dataclass
class Summary:
    sources: list[SourceStats]
    pairs: list[PairStats]
    earliest_ts: datetime | None
    token_age_hours: float | None
    notes: list[str] = field(default_factory=list)


def _average_ranks(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        average = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[order[k]] = average
        i = j + 1
    return ranks


def spearman(xs: list[float], ys: list[float]) -> float | None:
    n = len(xs)
    if n < MIN_PAIRS_FOR_RANK_CORRELATION or n != len(ys):
        return None
    rx, ry = _average_ranks(xs), _average_ranks(ys)
    mx, my = sum(rx) / n, sum(ry) / n
    sxx = sum((a - mx) ** 2 for a in rx)
    syy = sum((b - my) ** 2 for b in ry)
    if sxx == 0 or syy == 0:
        return None
    return sum((a - mx) * (b - my) for a, b in zip(rx, ry)) / math.sqrt(sxx * syy)


def _pair_stats(a: SourceData, b: SourceData) -> PairStats:
    rows_a = {row.wallet: row for row in a.rows}
    rows_b = {row.wallet: row for row in b.rows}
    shared = [w for w in rows_a if w in rows_b and rows_a[w].realized is not None and rows_b[w].realized is not None]
    xs = [rows_a[w].realized for w in shared]
    ys = [rows_b[w].realized for w in shared]
    abs_diffs = [abs(x - y) for x, y in zip(xs, ys)]
    rel_diffs = [abs(x - y) / max(abs(x), abs(y)) if max(abs(x), abs(y)) > 0 else 0.0 for x, y in zip(xs, ys)]
    overlap = None
    if len(a.rows) >= TOP_N and len(b.rows) >= TOP_N:
        top_a = {row.wallet for row in a.rows if row.rank <= TOP_N}
        top_b = {row.wallet for row in b.rows if row.rank <= TOP_N}
        overlap = len(top_a & top_b)
    return PairStats(
        a_label=a.label,
        b_label=b.label,
        shared=len(shared),
        median_abs_diff=median(abs_diffs) if abs_diffs else None,
        median_rel_diff=median(rel_diffs) if rel_diffs else None,
        spearman=spearman(xs, ys),
        top_overlap=overlap,
    )


def summarize(sources: list[SourceData], snapshot: datetime) -> Summary:
    stats = []
    for source in sources:
        firsts = [row.first_ts for row in source.rows if row.first_ts]
        lasts = [row.last_ts for row in source.rows if row.last_ts]
        stats.append(
            SourceStats(
                key=source.key,
                label=source.label,
                rows=len(source.rows),
                labeled_rows=sum(1 for row in source.rows if row.labels or row.token_tags),
                first_ts=min(firsts) if firsts else None,
                last_ts=max(lasts) if lasts else None,
                hit_limit=len(source.rows) >= LIST_LIMIT,
            )
        )
    pairs = [_pair_stats(a, b) for a, b in combinations(sources, 2)]
    earliest = min((s.first_ts for s in stats if s.first_ts), default=None)
    age_hours = (snapshot - earliest).total_seconds() / 3600 if earliest else None

    notes = [
        "Yang dibandingkan hanya realized PnL. Unrealized bergantung pada harga yang dipakai tiap provider saat menghitung, "
        "jadi hanya indikatif dan tidak dinilai selisihnya.",
    ]
    if len(sources) < 2:
        notes.append("Hanya satu sumber yang berhasil, jadi perbandingan lintas sumber tidak tersedia.")
    for stat in stats:
        if stat.hit_limit:
            notes.append(
                f"{stat.label} mengembalikan {stat.rows} baris (batas {LIST_LIMIT}). Wallet di luar daftar tidak terlihat, "
                f"jadi 'hanya di satu sumber' bisa disebabkan daftar yang terpotong."
            )
    if age_hours is not None and age_hours > 24 and any(s.key == "vybe" for s in stats):
        notes.append(
            f"Aktivitas tertua yang terlihat berumur sekitar {age_hours:.1f} jam. Vybe memakai jendela 1 hari, "
            f"sehingga tidak mencakup seluruh riwayat token ini."
        )
    for pair in pairs:
        if "Vybe" in (pair.a_label, pair.b_label) and pair.shared >= MIN_PAIRS_FOR_RANK_CORRELATION and (pair.median_rel_diff or 0) > 0.5:
            other = pair.b_label if pair.a_label == "Vybe" else pair.a_label
            notes.append(
                f"Selisih realized PnL antara Vybe dan {other} besar untuk wallet yang sama (median {pair.median_rel_diff:.0%}). "
                f"Periksa apakah angka Vybe memang dihitung khusus untuk token ini; itu belum terverifikasi."
            )
    return Summary(sources=stats, pairs=pairs, earliest_ts=earliest, token_age_hours=age_hours, notes=notes)
