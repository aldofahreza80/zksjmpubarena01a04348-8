from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Row:
    """One wallet as reported by one provider, in a provider-neutral shape."""

    source: str
    wallet: str
    rank: int
    sheet_row: int  # row number of this wallet in that provider's raw sheet (header = row 1)
    name: str | None = None
    labels: tuple[str, ...] = ()
    token_tags: tuple[str, ...] = ()
    wallet_type: str | None = None
    realized: float | None = None
    unrealized: float | None = None
    total: float | None = None
    invested: float | None = None
    proceeds: float | None = None
    buys: int | None = None
    sells: int | None = None
    first_ts: datetime | None = None
    last_ts: datetime | None = None
    funded_by: str | None = None
