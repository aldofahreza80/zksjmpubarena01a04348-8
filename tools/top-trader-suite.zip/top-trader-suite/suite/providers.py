from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderSpec:
    key: str  # short id; also the name of the per-run output sub-folder
    label: str  # name shown in the workbook
    folder: str  # provider folder next to run_all.py
    env_var: str  # API key variable the provider's CLI reads
    raw_args: tuple[str, ...] = ()  # extra CLI args that make the provider archive its raw API response
    fingerprint_files: tuple[str, ...] = ("main.py",)


PROVIDERS = (
    ProviderSpec("vybe", "Vybe", "vybe", "VYBE_API_KEY", (), ("main.py", "vybe.py", "csv_writer.py")),
    ProviderSpec("solanatracker", "SolanaTracker", "solanatracker", "SOLANATRACKER_API_KEY", ("--raw",), ("main.py", "solanatracker.py", "csv_writer.py")),
    ProviderSpec("gmgn", "GMGN", "gmgn", "GMGN_API_KEY", ("--raw",), ("main.py", "gmgn.py", "csv_writer.py")),
)
