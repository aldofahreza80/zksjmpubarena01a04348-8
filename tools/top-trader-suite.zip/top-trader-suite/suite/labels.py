"""Very small, deliberately conservative mapping of provider labels to common roles.

It exists only so the Gabungan sheet can point out when providers DISAGREE about a role
(for example GMGN says "dev" while Solana Tracker does not). Unknown labels are ignored here
but are always shown verbatim in the per-provider columns and raw sheets. Edit freely.
"""
from __future__ import annotations

from suite.model import Row

ROLE_MAP = {
    "dev": "dev", "developer": "dev", "creator": "dev", "deployer": "dev",
    "kol": "kol", "renowned": "kol", "influencer": "kol",
    "smart_degen": "smart_money", "smart_money": "smart_money",
    "sniper": "sniper",
    "bundler": "bundler",
    "bot": "bot", "potential_bot": "bot", "dex_bot": "bot",
    "arbitrage": "arbitrage", "mev": "arbitrage",
    "exchange": "pool_or_exchange", "pool": "pool_or_exchange", "lp": "pool_or_exchange",
    "liquidity_pool": "pool_or_exchange", "exchange_or_pool": "pool_or_exchange",
}


def normalize(label: str) -> str:
    return label.strip().lower().replace(" ", "_").replace("-", "_")


def roles_of(row: Row) -> frozenset[str]:
    found = set()
    candidates = list(row.labels) + list(row.token_tags)
    if row.wallet_type:
        candidates.append(row.wallet_type)
    for label in candidates:
        role = ROLE_MAP.get(normalize(label))
        if role:
            found.add(role)
    return frozenset(found)
