"""Read each provider's own CSV (the file its CLI already writes) into provider-neutral rows."""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import math
from pathlib import Path

from suite.model import Row


class AdapterError(Exception):
    pass


COLUMN_MAPS: dict[str, dict[str, str]] = {
    "vybe": {"wallet": "trader_address", "rank": "rank", "name": "name", "labels": "labels", "realized": "realized_pnl_usd"},
    "solanatracker": {
        "wallet": "wallet", "rank": "rank", "name": "identity_name", "labels": "labels", "realized": "realized_pnl_usd",
        "unrealized": "unrealized_pnl_usd", "total": "total_pnl_usd", "invested": "invested_usd", "proceeds": "proceeds_usd",
        "buys": "buys", "sells": "sells", "first": "first_trade_utc", "last": "last_trade_utc",
    },
    "gmgn": {
        "wallet": "wallet", "rank": "rank", "name": "identity_name", "labels": "labels", "token_tags": "token_tags",
        "wallet_type": "wallet_type", "realized": "realized_pnl_usd", "unrealized": "unrealized_pnl_usd",
        "total": "total_pnl_usd", "invested": "invested_usd", "proceeds": "proceeds_usd", "buys": "buys", "sells": "sells",
        "first": "first_hold_utc", "last": "last_active_utc", "funded_by": "funded_by",
    },
}
REQUIRED_FIELDS = ("wallet", "realized")

# Columns kept as text in the raw sheets; every other column is converted to a number when it parses as one.
TEXT_COLUMNS = frozenset({
    "wallet", "trader_address", "labels", "token_tags", "identity_name", "name", "twitter", "wallet_type",
    "first_trade_utc", "last_trade_utc", "first_hold_utc", "last_active_utc", "exit_utc", "funded_by", "transfer_in",
})


def read_csv_table(path: Path) -> tuple[list[str], list[list[str]]]:
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration:
            raise AdapterError("CSV kosong") from None
        rows = [row for row in reader if any(cell.strip() for cell in row)]
    return header, rows


def unescape_cell(text: str) -> str:
    """Undo the leading apostrophe the provider CSV writers add in front of text that starts with = + - @."""
    if len(text) > 1 and text[0] == "'" and text[1] in "=+-@\t\r":
        return text[1:]
    return text


def _finite(text: str) -> float | None:
    text = text.strip()
    if not text:
        return None
    try:
        value = float(text)
    except ValueError:
        return None
    return value if math.isfinite(value) else None


def _int(text: str) -> int | None:
    value = _finite(text)
    return int(value) if value is not None else None


def _timestamp(text: str) -> datetime | None:
    try:
        return datetime.strptime(text.strip(), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _split(text: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in text.split(";") if part.strip())


def rows_from_table(source: str, header: list[str], table: list[list[str]]) -> tuple[list[Row], list[str]]:
    mapping = COLUMN_MAPS.get(source)
    if mapping is None:
        raise AdapterError(f"sumber tidak dikenal: {source}")
    index = {name: position for position, name in enumerate(header)}
    missing = [mapping[field] for field in REQUIRED_FIELDS if mapping[field] not in index]
    if missing:
        raise AdapterError(f"kolom wajib tidak ada di CSV {source}: {', '.join(missing)} (kolom yang ada: {', '.join(header)})")

    def get(raw: list[str], field: str) -> str:
        column = mapping.get(field)
        position = index.get(column) if column else None
        if position is None or position >= len(raw):
            return ""
        return unescape_cell(raw[position].strip())

    rows: list[Row] = []
    warnings: list[str] = []
    seen: set[str] = set()
    for position, raw in enumerate(table):
        sheet_row = position + 2
        wallet = get(raw, "wallet")
        if not wallet:
            warnings.append(f"baris {sheet_row}: wallet kosong, dilewati")
            continue
        if wallet in seen:
            warnings.append(f"baris {sheet_row}: wallet duplikat {wallet}, dilewati")
            continue
        seen.add(wallet)
        realized_text = get(raw, "realized")
        realized = _finite(realized_text)
        if realized_text and realized is None:
            raise AdapterError(f"baris {sheet_row}: realized_pnl_usd bukan angka: {realized_text!r}")
        rank = _int(get(raw, "rank"))
        rows.append(
            Row(
                source=source,
                wallet=wallet,
                rank=rank if rank is not None else position + 1,
                sheet_row=sheet_row,
                name=get(raw, "name") or None,
                labels=_split(get(raw, "labels")),
                token_tags=_split(get(raw, "token_tags")),
                wallet_type=get(raw, "wallet_type") or None,
                realized=realized,
                unrealized=_finite(get(raw, "unrealized")),
                total=_finite(get(raw, "total")),
                invested=_finite(get(raw, "invested")),
                proceeds=_finite(get(raw, "proceeds")),
                buys=_int(get(raw, "buys")),
                sells=_int(get(raw, "sells")),
                first_ts=_timestamp(get(raw, "first")),
                last_ts=_timestamp(get(raw, "last")),
                funded_by=get(raw, "funded_by") or None,
            )
        )
    return rows, warnings
