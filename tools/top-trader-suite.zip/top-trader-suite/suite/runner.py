from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys
from typing import Callable, Iterable, Mapping

from suite.providers import ProviderSpec

MAX_LOG_CHARS = 8000
MIN_SECRET_LENGTH = 6


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class RunResult:
    spec: ProviderSpec
    status: str = "pending"  # ok | failed | timeout | error | skipped
    note: str = ""
    command: list[str] = field(default_factory=list)
    cwd: Path | None = None
    started: datetime | None = None
    ended: datetime | None = None
    returncode: int | None = None
    stdout: str = ""
    stderr: str = ""
    csv_path: Path | None = None
    extra_files: list[Path] = field(default_factory=list)

    @property
    def elapsed(self) -> float | None:
        if self.started is None or self.ended is None:
            return None
        return (self.ended - self.started).total_seconds()


def redact(text: str, secrets: Iterable[str]) -> str:
    for secret in sorted({s for s in secrets if s and len(s) >= MIN_SECRET_LENGTH}, key=len, reverse=True):
        text = text.replace(secret, "***")
    return text


def tail(text: str, limit: int = MAX_LOG_CHARS) -> str:
    return text if len(text) <= limit else "[dipotong] ..." + text[-limit:]


def last_line(text: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return lines[-1] if lines else ""


def _as_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def build_child_env(spec: ProviderSpec, keys: Mapping[str, str], all_env_vars: Iterable[str], base_env: Mapping[str, str]) -> dict[str, str]:
    """Environment for one provider process: it sees ITS OWN key only, never the other providers' keys."""
    env = dict(base_env)
    for var in all_env_vars:
        env.pop(var, None)
    env[spec.env_var] = keys[spec.env_var]
    env["PYTHONUTF8"] = "1"  # token names often contain emoji; keep piped output from crashing on Windows code pages
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def run_provider(
    spec: ProviderSpec,
    *,
    provider_dir: Path,
    mint: str,
    work_dir: Path,
    keys: Mapping[str, str],
    all_env_vars: Iterable[str],
    timeout: float,
    raw_json: bool = True,
    python: str | None = None,
    base_env: Mapping[str, str] | None = None,
    now: Callable[[], datetime] = utc_now,
) -> RunResult:
    """Run one provider's own CLI unchanged, in its own working folder, and collect what it wrote to ./output."""
    result = RunResult(spec=spec)
    secrets = [value for value in keys.values() if value]
    if not keys.get(spec.env_var):
        result.status = "skipped"
        result.note = f"{spec.env_var} tidak ditemukan; isi di .env root atau set sebagai environment variable"
        return result
    main_py = Path(provider_dir) / "main.py"
    if not main_py.is_file():
        result.status, result.note = "error", f"main.py tidak ditemukan di {provider_dir}"
        return result
    cwd = Path(work_dir) / spec.key
    cwd.mkdir(parents=True, exist_ok=True)
    command = [python or sys.executable, str(main_py), mint]
    if raw_json:
        command.extend(spec.raw_args)
    env = build_child_env(spec, keys, all_env_vars, os.environ if base_env is None else base_env)
    result.command, result.cwd, result.started = command, cwd, now()
    try:
        completed = subprocess.run(
            command, cwd=str(cwd), env=env, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, stdin=subprocess.DEVNULL,
        )
    except subprocess.TimeoutExpired as exc:
        result.ended = now()
        result.stdout = tail(redact(_as_text(exc.stdout), secrets))
        result.stderr = tail(redact(_as_text(exc.stderr), secrets))
        result.status, result.note = "timeout", f"melebihi batas waktu {timeout:g} detik"
        return result
    except OSError as exc:
        result.ended = now()
        result.status, result.note = "error", redact(f"gagal menjalankan proses: {exc}", secrets)
        return result
    result.ended = now()
    result.returncode = completed.returncode
    result.stdout = tail(redact(completed.stdout or "", secrets))
    result.stderr = tail(redact(completed.stderr or "", secrets))
    output_dir = cwd / "output"
    csvs = sorted(output_dir.glob("*.csv"), key=lambda path: path.stat().st_mtime) if output_dir.is_dir() else []
    result.extra_files = sorted(output_dir.glob("*.json")) if output_dir.is_dir() else []
    if completed.returncode == 0 and csvs:
        result.status, result.csv_path = "ok", csvs[-1]
    elif completed.returncode == 0:
        result.status, result.note = "failed", "proses selesai tanpa membuat CSV"
    else:
        note = last_line(result.stderr) or last_line(result.stdout) or f"kode keluar {completed.returncode}"
        if csvs:
            note += " (CSV ada tetapi tidak dipakai karena proses gagal)"
        result.status, result.note = "failed", note[:400]
    return result


def run_providers(
    specs: list[ProviderSpec],
    *,
    root: Path,
    mint: str,
    work_dir: Path,
    keys: Mapping[str, str],
    all_env_vars: Iterable[str],
    timeout: float,
    raw_json: bool = True,
    python: str | None = None,
    base_env: Mapping[str, str] | None = None,
    on_done: Callable[[RunResult], None] | None = None,
) -> list[RunResult]:
    """Run all providers in parallel; one failing provider never stops the others. Results keep the order of `specs`."""
    all_env_vars = list(all_env_vars)

    def job(spec: ProviderSpec) -> RunResult:
        return run_provider(
            spec, provider_dir=Path(root) / spec.folder, mint=mint, work_dir=work_dir, keys=keys, all_env_vars=all_env_vars,
            timeout=timeout, raw_json=raw_json, python=python, base_env=base_env,
        )

    results: dict[str, RunResult] = {}
    with ThreadPoolExecutor(max_workers=max(1, len(specs))) as pool:
        futures = {pool.submit(job, spec): spec for spec in specs}
        for future in as_completed(futures):
            spec = futures[future]
            try:
                result = future.result()
            except Exception as exc:  # a bug here must never hide the other providers' results
                result = RunResult(spec=spec, status="error", note=f"kesalahan internal: {exc!r}")
            results[spec.key] = result
            if on_done is not None:
                on_done(result)
    return [results[spec.key] for spec in specs]
