# soltracker-top-trader-cli

Exports the top traders of one Solana token, **since the token's launch**, ranked by **realized PnL on that token**,
using the Solana Tracker Data API (PnL V2: `GET /v2/pnl/tokens/{token}/traders`). Wallet labels
(developer, KOL, bot, pool, exchange, platform tags...) are kept in the CSV, not filtered out.

This is a separate tool from the Vybe-based `top-trader-cli`. The two use different PnL definitions, so their numbers
will differ on purpose; compare them rather than expecting a match.

## Setup

```powershell
pip install -r requirements.txt
$env:SOLANATRACKER_API_KEY = "your-key"     # or copy .env.example to .env and fill it in
python main.py <mint>
```

(bash: `export SOLANATRACKER_API_KEY=your-key`)

The CSV is written to `output\solanatracker_top_traders_<mint>_<UTC timestamp>.csv`.

## Options

| Option | Effect |
| --- | --- |
| `--limit N` | Max traders to export (default 100). Pages are fetched automatically; each page is one API request. |
| `--exclude-arbitrage` | Drop confirmed arbitrage/MEV wallets. Kept by default so they show up with their label. |
| `--exclude-zero-buys` | Drop wallets with no recorded buys. Kept by default so developer/sniper wallets that never "bought" still appear. |
| `--raw` | Also save the raw API responses as `.raw.json` next to the CSV (useful for checking fields). |

## CSV columns

`rank, wallet, labels, identity_name` - labels are `;`-separated (e.g. `developer;axiom`).
`realized_pnl_usd, unrealized_pnl_usd, total_pnl_usd` - PnL on this token.
`roi` - exactly as the API returns it (unit not documented, so it is not converted).
`invested_usd, proceeds_usd, buys, sells` - cost basis and sales. A wallet with `buys = 0` and `invested_usd = 0` usually
received tokens without buying them (dev allocation, transfer), so its realized PnL is simply what it sold.
`first_trade_utc, last_trade_utc, hold_time_secs` - timing (UTC).
`balance, value_usd` - what the wallet still holds of this token.
`wallet_lifetime_realized_pnl_usd, wallet_lifetime_trades, wallet_tokens_traded` - the wallet's PnL across all tokens, to
tell a one-off lucky wallet from a consistently profitable one.

Text from the API (names, labels) is prefixed with `'` if it starts with `= + - @`, so Excel never runs it as a formula.

## Notes

- Solana Tracker's PnL excludes SOL and stablecoins and covers wallets from December 2023 onward.
- Free plan quota and rate limit are on the Solana Tracker pricing page; check your dashboard for your real numbers.
- Tests: `python -m unittest discover`
