import unittest

import requests

from solanatracker import (
    SolanaTrackerClient,
    SolanaTrackerHttpError,
    SolanaTrackerNetworkError,
    SolanaTrackerResponseError,
)

MINT = "7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq"


class FakeResponse:
    def __init__(self, status_code, payload, headers=None):
        self.status_code, self._payload, self.headers = status_code, payload, headers or {}

    def json(self):
        return self._payload

    @property
    def text(self):
        return str(self._payload)


class FakeSession:
    def __init__(self, responses):
        self.responses, self.calls = iter(responses), []

    def get(self, url, *, headers, params, timeout):
        self.calls.append((url, headers, dict(params), timeout))
        response = next(self.responses)
        if isinstance(response, Exception):
            raise response
        return response


def row(wallet="W1", realized=12.5, **overrides):
    data = {
        "wallet": wallet,
        "pnl": {
            "token": {"realized": realized, "unrealized": 3.0, "total": 15.5},
            "wallet": {"realized": 1000.0, "unrealized": 5.0, "total": 1005.0, "invested": 10.0, "proceeds": 20.0, "totalTrades": 250, "tokensTraded": 40},
        },
        "identity": {"name": "Dev Dan", "type": "developer", "tags": ["developer", "axiom"]},
        "counts": {"buys": 2, "sells": 3, "total": 5},
        "roi": 0.125,
        "invested": 100.0,
        "proceeds": 112.5,
        "current": {"balance": 10.0, "costBasis": 1.0, "value": 2.5, "price": 0.25, "avgCost": None},
        "timing": {"firstTrade": 1_700_000_000_000, "lastTrade": 1_700_000_100_000, "holdTimeSecs": 100},
    }
    data.update(overrides)
    return data


def page(rows, has_more=False, cursor=None, total=None):
    return {
        "meta": {"symbol": "TKN", "name": "Token Name", "decimals": 6, "price": 0.25, "marketCap": None, "liquidity": None, "primaryMarket": None},
        "traders": rows,
        "pagination": {"hasMore": has_more, "nextCursor": cursor, "count": len(rows), "total": total if total is not None else len(rows)},
    }


def client(session, sleeps=None):
    return SolanaTrackerClient("secret", session=session, sleep=(sleeps.append if sleeps is not None else (lambda _: None)))


class SolanaTrackerClientTests(unittest.TestCase):
    def test_request_config_and_row_parsing(self):
        session = FakeSession([FakeResponse(200, page([row()]))])
        result = client(session).fetch_token_traders(MINT)
        url, headers, params, timeout = session.calls[0]
        self.assertEqual(url, f"https://data.solanatracker.io/v2/pnl/tokens/{MINT}/traders")
        self.assertEqual(headers["x-api-key"], "secret")
        self.assertEqual(params, {"sort": "realized", "direction": "desc", "excludeArbitrage": "false", "excludeZeroBuys": "false", "limit": 100})
        self.assertEqual(timeout, 20)
        trader = result.traders[0]
        self.assertEqual((result.symbol, result.name, result.total), ("TKN", "Token Name", 1))
        self.assertEqual((trader.wallet, trader.labels, trader.identity_name), ("W1", ["developer", "axiom"], "Dev Dan"))
        self.assertEqual((trader.realized_pnl_usd, trader.unrealized_pnl_usd, trader.total_pnl_usd), (12.5, 3.0, 15.5))
        self.assertEqual((trader.roi, trader.invested_usd, trader.proceeds_usd, trader.buys, trader.sells), (0.125, 100.0, 112.5, 2, 3))
        self.assertEqual((trader.first_trade_ms, trader.last_trade_ms, trader.hold_time_secs), (1_700_000_000_000, 1_700_000_100_000, 100.0))
        self.assertEqual((trader.balance, trader.value_usd), (10.0, 2.5))
        self.assertEqual((trader.wallet_realized_pnl_usd, trader.wallet_total_trades, trader.wallet_tokens_traded), (1000.0, 250, 40))

    def test_filter_flags_are_sent(self):
        session = FakeSession([FakeResponse(200, page([row()]))])
        client(session).fetch_token_traders(MINT, 5, exclude_arbitrage=True, exclude_zero_buys=True)
        params = session.calls[0][2]
        self.assertEqual((params["excludeArbitrage"], params["excludeZeroBuys"], params["limit"]), ("true", "true", 5))

    def test_pagination_passes_cursor_and_stops_at_limit(self):
        session = FakeSession([
            FakeResponse(200, page([row("A"), row("B")], has_more=True, cursor="CUR1", total=5)),
            FakeResponse(200, page([row("C"), row("D")], has_more=True, cursor="CUR2", total=5)),
        ])
        sleeps = []
        result = client(session, sleeps).fetch_token_traders(MINT, 3)
        self.assertEqual([t.wallet for t in result.traders], ["A", "B", "C"])
        self.assertEqual(len(session.calls), 2)
        self.assertNotIn("cursor", session.calls[0][2]); self.assertEqual(session.calls[0][2]["limit"], 3)
        self.assertEqual(session.calls[1][2]["cursor"], "CUR1"); self.assertEqual(session.calls[1][2]["limit"], 1)
        self.assertEqual(result.total, 5); self.assertEqual(len(sleeps), 1)

    def test_pagination_stops_when_no_more(self):
        session = FakeSession([FakeResponse(200, page([row("A")], has_more=False, cursor=None))])
        result = client(session).fetch_token_traders(MINT, 100)
        self.assertEqual(len(result.traders), 1); self.assertEqual(len(session.calls), 1)

    def test_null_fields_and_missing_identity_are_tolerated(self):
        sparse = {"wallet": "W2", "pnl": {"token": {"realized": -3.5, "unrealized": None, "total": None}}, "identity": None}
        trader = client(FakeSession([FakeResponse(200, page([sparse]))])).fetch_token_traders(MINT).traders[0]
        self.assertEqual((trader.labels, trader.identity_name, trader.realized_pnl_usd), ([], None, -3.5))
        self.assertIsNone(trader.roi); self.assertIsNone(trader.first_trade_ms); self.assertIsNone(trader.wallet_total_trades)

    def test_primary_type_used_when_no_tags(self):
        r = row(identity={"name": None, "type": "kol"})
        self.assertEqual(client(FakeSession([FakeResponse(200, page([r]))])).fetch_token_traders(MINT).traders[0].labels, ["kol"])

    def test_legacy_position_fields_used_as_fallback(self):
        r = row(); del r["current"]; r["position"] = {"balance": 7.0, "value": 9.0}
        trader = client(FakeSession([FakeResponse(200, page([r]))])).fetch_token_traders(MINT).traders[0]
        self.assertEqual((trader.balance, trader.value_usd), (7.0, 9.0))

    def test_retries_429_then_succeeds(self):
        session = FakeSession([FakeResponse(429, {"error": "slow down"}, {"Retry-After": "3"}), FakeResponse(200, page([row()]))])
        sleeps = []
        result = client(session, sleeps).fetch_token_traders(MINT)
        self.assertEqual(len(result.traders), 1); self.assertEqual(sleeps, [3.0])

    def test_gives_up_after_retries(self):
        session = FakeSession([FakeResponse(500, {"error": "boom"})] * 3)
        with self.assertRaises(SolanaTrackerHttpError) as ctx:
            client(session).fetch_token_traders(MINT)
        self.assertEqual(ctx.exception.status_code, 500); self.assertEqual(len(session.calls), 3)

    def test_403_fails_without_retry(self):
        session = FakeSession([FakeResponse(403, {"error": "Plan does not include this endpoint"})])
        with self.assertRaises(SolanaTrackerHttpError) as ctx:
            client(session).fetch_token_traders(MINT)
        self.assertIn("403", str(ctx.exception)); self.assertIn("Plan does not include", str(ctx.exception)); self.assertEqual(len(session.calls), 1)

    def test_network_error_after_retries(self):
        session = FakeSession([requests.ConnectionError("down")] * 3)
        with self.assertRaises(SolanaTrackerNetworkError):
            client(session).fetch_token_traders(MINT)

    def test_missing_traders_array_reports_keys(self):
        with self.assertRaises(SolanaTrackerResponseError) as ctx:
            client(FakeSession([FakeResponse(200, {"data": [], "oops": 1})])).fetch_token_traders(MINT)
        self.assertIn("data", str(ctx.exception)); self.assertIn("oops", str(ctx.exception))

    def test_row_without_wallet_reports_keys(self):
        with self.assertRaises(SolanaTrackerResponseError) as ctx:
            client(FakeSession([FakeResponse(200, page([{"foo": "bar"}]))])).fetch_token_traders(MINT)
        self.assertIn("foo", str(ctx.exception))

    def test_invalid_realized_value_reports_row(self):
        with self.assertRaises(SolanaTrackerResponseError) as ctx:
            client(FakeSession([FakeResponse(200, page([row(pnl={"token": {"realized": {"x": 1}}})]))])).fetch_token_traders(MINT)
        self.assertIn("pnl.token.realized", str(ctx.exception))

    def test_all_realized_missing_is_an_error_with_preview(self):
        r = {"wallet": "W", "pnl": {"unexpected": {"realized": 1}}}
        with self.assertRaises(SolanaTrackerResponseError) as ctx:
            client(FakeSession([FakeResponse(200, page([r, r]))])).fetch_token_traders(MINT)
        self.assertIn("unexpected", str(ctx.exception))

    def test_invalid_mint_and_limit_rejected_before_any_request(self):
        session = FakeSession([])
        for bad in ("", "short", "../../etc/passwd", MINT + "/x"):
            with self.assertRaises(ValueError):
                client(session).fetch_token_traders(bad)
        with self.assertRaises(ValueError):
            client(session).fetch_token_traders(MINT, 0)
        self.assertEqual(session.calls, [])

    def test_empty_traders_is_ok(self):
        self.assertEqual(client(FakeSession([FakeResponse(200, page([]))])).fetch_token_traders(MINT).traders, [])


if __name__ == "__main__":
    unittest.main()
