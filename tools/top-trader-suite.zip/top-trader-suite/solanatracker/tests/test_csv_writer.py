import csv
from pathlib import Path
import tempfile
import unittest

from csv_writer import CSV_COLUMNS, write_traders_csv
from solanatracker import Trader


def trader(**overrides):
    base = dict(
        wallet="W1", labels=["developer", "axiom"], identity_name="Dev Dan", realized_pnl_usd=12.5, unrealized_pnl_usd=3.0,
        total_pnl_usd=15.5, roi=0.125, invested_usd=100.0, proceeds_usd=112.5, buys=2, sells=3,
        first_trade_ms=1_700_000_000_000, last_trade_ms=None, hold_time_secs=100.0, balance=10.0, value_usd=2.5,
        wallet_realized_pnl_usd=1000.0, wallet_total_trades=250, wallet_tokens_traded=40,
    )
    base.update(overrides)
    return Trader(**base)


def read(traders):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "nested" / "out.csv"
        write_traders_csv(path, traders)
        with path.open(newline="", encoding="utf-8") as handle:
            return list(csv.DictReader(handle))


class CsvWriterTests(unittest.TestCase):
    def test_columns_rank_labels_and_timestamps(self):
        rows = read([trader(), trader(wallet="W2", labels=[], identity_name=None, realized_pnl_usd=-3.5)])
        self.assertEqual(list(rows[0]), CSV_COLUMNS)
        self.assertEqual([r["rank"] for r in rows], ["1", "2"])
        self.assertEqual(rows[0]["labels"], "developer;axiom")
        self.assertEqual(rows[0]["first_trade_utc"], "2023-11-14T22:13:20Z")
        self.assertEqual(rows[0]["last_trade_utc"], "")
        self.assertEqual((rows[1]["labels"], rows[1]["identity_name"], rows[1]["realized_pnl_usd"]), ("", "", "-3.5"))

    def test_none_numbers_are_blank(self):
        row = read([trader(unrealized_pnl_usd=None, roi=None, wallet_total_trades=None)])[0]
        self.assertEqual((row["unrealized_pnl_usd"], row["roi"], row["wallet_lifetime_trades"]), ("", "", ""))

    def test_formula_like_text_is_neutralised(self):
        row = read([trader(identity_name="=HYPERLINK(\"http://x\")", labels=["+evil"])])[0]
        self.assertEqual(row["identity_name"], "'=HYPERLINK(\"http://x\")")
        self.assertEqual(row["labels"], "'+evil")

    def test_negative_numbers_stay_numeric(self):
        self.assertEqual(read([trader(realized_pnl_usd=-12.0)])[0]["realized_pnl_usd"], "-12.0")


if __name__ == "__main__":
    unittest.main()
