from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from solanatracker import Trader

CSV_COLUMNS = [
    "rank",
    "wallet",
    "labels",
    "identity_name",
    "realized_pnl_usd",
    "unrealized_pnl_usd",
    "total_pnl_usd",
    "roi",
    "invested_usd",
    "proceeds_usd",
    "buys",
    "sells",
    "first_trade_utc",
    "last_trade_utc",
    "hold_time_secs",
    "balance",
    "value_usd",
    "wallet_lifetime_realized_pnl_usd",
    "wallet_lifetime_trades",
    "wallet_tokens_traded",
]
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _cell_text(value: str | None) -> str:
    """Stop spreadsheet apps from running API-provided names/labels as formulas."""
    text = value or ""
    return "'" + text if text.startswith(FORMULA_PREFIXES) else text


def _format_ms(value: int | None) -> str:
    if value is None:
        return ""
    try:
        return datetime.fromtimestamp(value / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    except (OverflowError, OSError, ValueError):
        return ""


def write_traders_csv(path: Path, traders: list[Trader]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for rank, trader in enumerate(traders, start=1):
            writer.writerow(
                {
                    "rank": rank,
                    "wallet": _cell_text(trader.wallet),
                    "labels": _cell_text(";".join(trader.labels)),
                    "identity_name": _cell_text(trader.identity_name),
                    "realized_pnl_usd": trader.realized_pnl_usd,
                    "unrealized_pnl_usd": trader.unrealized_pnl_usd,
                    "total_pnl_usd": trader.total_pnl_usd,
                    "roi": trader.roi,
                    "invested_usd": trader.invested_usd,
                    "proceeds_usd": trader.proceeds_usd,
                    "buys": trader.buys,
                    "sells": trader.sells,
                    "first_trade_utc": _format_ms(trader.first_trade_ms),
                    "last_trade_utc": _format_ms(trader.last_trade_ms),
                    "hold_time_secs": trader.hold_time_secs,
                    "balance": trader.balance,
                    "value_usd": trader.value_usd,
                    "wallet_lifetime_realized_pnl_usd": trader.wallet_realized_pnl_usd,
                    "wallet_lifetime_trades": trader.wallet_total_trades,
                    "wallet_tokens_traded": trader.wallet_tokens_traded,
                }
            )
