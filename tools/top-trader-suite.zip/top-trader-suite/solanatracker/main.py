from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys

from csv_writer import write_traders_csv
from solanatracker import SolanaTrackerClient, SolanaTrackerError, SolanaTrackerHttpError

OUTPUT_DIR = Path("output")
ENV_VAR = "SOLANATRACKER_API_KEY"
HTTP_HINTS = {
    401: "Check that SOLANATRACKER_API_KEY is correct.",
    403: "Your key or plan may not include this endpoint.",
    429: "Rate limit or monthly request quota reached.",
}


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def safe_mint_for_filename(mint: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", mint)


def load_env_file(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE lines). Real environment variables win."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Export a token's top traders since launch, ranked by realized PnL, from Solana Tracker (PnL V2)."
    )
    parser.add_argument("mint", nargs="?", help="Solana token mint address")
    parser.add_argument("--limit", type=int, default=100, help="max traders to export (default: 100)")
    parser.add_argument("--exclude-arbitrage", action="store_true", help="drop confirmed arbitrage/MEV wallets (kept by default)")
    parser.add_argument("--exclude-zero-buys", action="store_true", help="drop wallets with no recorded buys (kept by default)")
    parser.add_argument("--raw", action="store_true", help="also save the raw API responses as JSON next to the CSV")
    args = parser.parse_args(argv)
    if not args.mint:
        parser.print_usage(sys.stderr)
        return 2
    load_env_file(Path(__file__).parent / ".env")
    api_key = os.environ.get(ENV_VAR)
    if not api_key:
        print(f"Error: {ENV_VAR} environment variable is required.", file=sys.stderr)
        return 1
    try:
        result = SolanaTrackerClient(api_key).fetch_token_traders(
            args.mint,
            args.limit,
            exclude_arbitrage=args.exclude_arbitrage,
            exclude_zero_buys=args.exclude_zero_buys,
        )
        if not result.traders:
            print("Error: Solana Tracker returned no traders for this token.", file=sys.stderr)
            return 1
        stem = f"solanatracker_top_traders_{safe_mint_for_filename(args.mint.strip())}_{utc_timestamp()}"
        output_path = OUTPUT_DIR / f"{stem}.csv"
        write_traders_csv(output_path, result.traders)
        if args.raw:
            (OUTPUT_DIR / f"{stem}.raw.json").write_text(json.dumps(result.pages, indent=2), encoding="utf-8")
    except SolanaTrackerHttpError as exc:
        hint = HTTP_HINTS.get(exc.status_code)
        print(f"Error: {exc}" + (f" {hint}" if hint else ""), file=sys.stderr)
        return 1
    except (SolanaTrackerError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    token = " ".join(part for part in (result.symbol, f"({result.name})" if result.name else None) if part)
    of_total = f" of {result.total}" if result.total and result.total > len(result.traders) else ""
    print(f"Created {output_path} ({len(result.traders)}{of_total} traders)" + (f" - {token}" if token else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
