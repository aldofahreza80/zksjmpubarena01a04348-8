"""Solana Tracker (solanatracker.io) Data API adapter.

Fetches the traders of ONE token from the PnL V2 endpoint
GET /v2/pnl/tokens/{token}/traders, sorted by realized PnL on that token.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import re
import time
from typing import Callable, Protocol
from urllib.parse import quote

import requests

BASE_URL = "https://data.solanatracker.io"
TIMEOUT_SECONDS = 20
MAX_RETRIES = 2
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
PAGE_SIZE = 100
MAX_PAGES = 50
PAGE_DELAY_SECONDS = 0.4  # free plan: 3 requests/second
MAX_RETRY_WAIT_SECONDS = 10
MINT_PATTERN = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")


@dataclass(frozen=True)
class Trader:
    wallet: str
    labels: list[str]
    identity_name: str | None
    realized_pnl_usd: float | None
    unrealized_pnl_usd: float | None
    total_pnl_usd: float | None
    roi: float | None
    invested_usd: float | None
    proceeds_usd: float | None
    buys: int | None
    sells: int | None
    first_trade_ms: int | None
    last_trade_ms: int | None
    hold_time_secs: float | None
    balance: float | None
    value_usd: float | None
    wallet_realized_pnl_usd: float | None
    wallet_total_trades: int | None
    wallet_tokens_traded: int | None


@dataclass(frozen=True)
class TokenTraders:
    symbol: str | None
    name: str | None
    total: int | None
    traders: list[Trader]
    pages: list[dict]


class Session(Protocol):
    def get(self, url: str, *, headers: dict[str, str], params: dict[str, object], timeout: int): ...


class SolanaTrackerError(Exception):
    """Base class for errors raised by the Solana Tracker adapter."""


class SolanaTrackerHttpError(SolanaTrackerError):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"Solana Tracker API error {status_code}: {message}")


class SolanaTrackerResponseError(SolanaTrackerError):
    pass


class SolanaTrackerNetworkError(SolanaTrackerError):
    pass


def _dig(obj: object, *path: str) -> object:
    for key in path:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(key)
    return obj


def _first(*values: object) -> object:
    return next((value for value in values if value is not None), None)


def _num(value: object) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value.replace(",", "").lstrip("$"))
        except ValueError:
            return None
    return None


def _int(value: object) -> int | None:
    number = _num(value)
    return int(number) if number is not None else None


def _text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _preview(row: object) -> str:
    return json.dumps(row, default=str)[:400]


class SolanaTrackerClient:
    def __init__(self, api_key: str, *, session: Session | None = None, sleep: Callable[[float], None] = time.sleep) -> None:
        if not api_key:
            raise ValueError("API key is required")
        self._api_key = api_key
        self._session = session or requests.Session()
        self._sleep = sleep

    def fetch_token_traders(
        self,
        mint_address: str,
        limit: int = 100,
        *,
        exclude_arbitrage: bool = False,
        exclude_zero_buys: bool = False,
    ) -> TokenTraders:
        mint = mint_address.strip()
        if not MINT_PATTERN.match(mint):
            raise ValueError("Mint address is not a valid Solana address")
        if limit < 1:
            raise ValueError("Limit must be at least 1")
        url = f"{BASE_URL}/v2/pnl/tokens/{quote(mint, safe='')}/traders"
        filters = {
            "sort": "realized",
            "direction": "desc",
            "excludeArbitrage": str(exclude_arbitrage).lower(),
            "excludeZeroBuys": str(exclude_zero_buys).lower(),
        }
        traders: list[Trader] = []
        pages: list[dict] = []
        symbol = name = None
        total: int | None = None
        cursor: str | None = None
        for page_number in range(MAX_PAGES):
            params: dict[str, object] = {**filters, "limit": min(PAGE_SIZE, limit - len(traders))}
            if cursor:
                params["cursor"] = cursor
            payload = self._get_json(url, params)
            rows = payload.get("traders") if isinstance(payload, dict) else None
            if not isinstance(rows, list):
                keys = ", ".join(sorted(payload)) if isinstance(payload, dict) else type(payload).__name__
                raise SolanaTrackerResponseError(f"Solana Tracker response is missing a traders array (got: {keys})")
            pages.append(payload)
            symbol = symbol or _text(_dig(payload, "meta", "symbol"))
            name = name or _text(_dig(payload, "meta", "name"))
            if total is None:
                total = _int(_dig(payload, "pagination", "total"))
            for row in rows:
                traders.append(self._parse_trader(row, len(traders) + 1))
            pagination = payload.get("pagination")
            next_cursor = pagination.get("nextCursor") if isinstance(pagination, dict) else None
            has_more = isinstance(pagination, dict) and bool(pagination.get("hasMore"))
            if len(traders) >= limit or not rows or not has_more or not next_cursor:
                break
            cursor = str(next_cursor)
            self._sleep(PAGE_DELAY_SECONDS)
        traders = traders[:limit]
        if traders and all(trader.realized_pnl_usd is None for trader in traders):
            raise SolanaTrackerResponseError(
                f"No trader row has pnl.token.realized, so they cannot be ranked. First row: {_preview(pages[0]['traders'][0])}"
            )
        return TokenTraders(symbol=symbol, name=name, total=total, traders=traders, pages=pages)

    def _get_json(self, url: str, params: dict[str, object]) -> object:
        headers = {"x-api-key": self._api_key, "Accept": "application/json"}
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = self._session.get(url, headers=headers, params=params, timeout=TIMEOUT_SECONDS)
            except requests.RequestException as exc:
                if attempt < MAX_RETRIES:
                    self._sleep(2**attempt)
                    continue
                raise SolanaTrackerNetworkError(f"Network error contacting Solana Tracker: {exc}") from exc
            if response.status_code == 200:
                try:
                    return response.json()
                except (ValueError, TypeError) as exc:
                    raise SolanaTrackerResponseError("Solana Tracker returned invalid JSON") from exc
            error = SolanaTrackerHttpError(response.status_code, self._error_message(response))
            if response.status_code not in RETRYABLE_STATUS_CODES or attempt >= MAX_RETRIES:
                raise error
            self._sleep(self._retry_wait(response, attempt))
        raise SolanaTrackerError("Solana Tracker request failed unexpectedly")

    @staticmethod
    def _retry_wait(response: object, attempt: int) -> float:
        headers = getattr(response, "headers", None) or {}
        try:
            wait = float(headers.get("Retry-After"))
        except (TypeError, ValueError):
            wait = 2**attempt
        return min(max(wait, 0.0), MAX_RETRY_WAIT_SECONDS)

    @staticmethod
    def _error_message(response: object) -> str:
        try:
            payload = response.json()
        except (ValueError, TypeError):
            return str(getattr(response, "text", "Request failed"))[:300]
        if isinstance(payload, dict):
            return str(payload.get("message") or payload.get("error") or "Request failed")
        return "Request failed"

    @staticmethod
    def _parse_trader(row: object, index: int) -> Trader:
        if not isinstance(row, dict):
            raise SolanaTrackerResponseError(f"Trader row {index} is not an object")
        wallet = _text(row.get("wallet"))
        if wallet is None:
            raise SolanaTrackerResponseError(f"Trader row {index} has no wallet (row keys: {', '.join(sorted(row))})")
        raw_realized = _dig(row, "pnl", "token", "realized")
        realized = _num(raw_realized)
        if raw_realized is not None and realized is None:
            raise SolanaTrackerResponseError(
                f"Trader row {index} has invalid pnl.token.realized (value: {raw_realized!r}). Row: {_preview(row)}"
            )
        identity = row.get("identity") if isinstance(row.get("identity"), dict) else {}
        tags = identity.get("tags")
        labels = [tag for tag in tags if isinstance(tag, str) and tag] if isinstance(tags, list) else []
        if not labels and _text(identity.get("type")):
            labels = [identity["type"]]
        return Trader(
            wallet=wallet,
            labels=labels,
            identity_name=_text(identity.get("name")),
            realized_pnl_usd=realized,
            unrealized_pnl_usd=_num(_dig(row, "pnl", "token", "unrealized")),
            total_pnl_usd=_num(_dig(row, "pnl", "token", "total")),
            roi=_num(row.get("roi")),
            invested_usd=_num(_first(row.get("invested"), _dig(row, "volume", "buyUsd"))),
            proceeds_usd=_num(_first(row.get("proceeds"), _dig(row, "volume", "sellUsd"))),
            buys=_int(_dig(row, "counts", "buys")),
            sells=_int(_dig(row, "counts", "sells")),
            first_trade_ms=_int(_dig(row, "timing", "firstTrade")),
            last_trade_ms=_int(_dig(row, "timing", "lastTrade")),
            hold_time_secs=_num(_dig(row, "timing", "holdTimeSecs")),
            balance=_num(_first(_dig(row, "current", "balance"), _dig(row, "position", "balance"))),
            value_usd=_num(_first(_dig(row, "current", "value"), _dig(row, "position", "value"))),
            wallet_realized_pnl_usd=_num(_dig(row, "pnl", "wallet", "realized")),
            wallet_total_trades=_int(_dig(row, "pnl", "wallet", "totalTrades")),
            wallet_tokens_traded=_int(_dig(row, "pnl", "wallet", "tokensTraded")),
        )
