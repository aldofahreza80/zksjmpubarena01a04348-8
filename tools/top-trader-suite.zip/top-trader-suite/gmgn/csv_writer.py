from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from gmgn import Trader

# Names shared with the Solana Tracker CSV (wallet, labels, identity_name, *_pnl_usd, invested_usd,
# proceeds_usd, buys, sells, balance, value_usd) are kept identical so the two files are easy to compare.
CSV_COLUMNS = [
    "rank",
    "wallet",
    "labels",
    "token_tags",
    "identity_name",
    "twitter",
    "wallet_type",
    "realized_pnl_usd",
    "unrealized_pnl_usd",
    "total_pnl_usd",
    "realized_pnl_ratio",
    "total_pnl_ratio",
    "invested_usd",
    "proceeds_usd",
    "total_cost_usd",
    "buy_volume_usd",
    "sell_volume_usd",
    "buys",
    "sells",
    "avg_buy_price",
    "avg_sell_price",
    "balance",
    "value_usd",
    "supply_ratio",
    "first_hold_utc",
    "last_active_utc",
    "exit_utc",
    "funded_by",
    "transfer_in",
    "gmgn_rank",
]
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _cell_text(value: str | None) -> str:
    """Stop spreadsheet apps from running API-provided names/labels as formulas."""
    text = value or ""
    return "'" + text if text.startswith(FORMULA_PREFIXES) else text


def _format_ts(value: int | None) -> str:
    if not value:
        return ""
    try:
        return datetime.fromtimestamp(value, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    except (OverflowError, OSError, ValueError):
        return ""


def _sort_key(trader: Trader) -> tuple[int, float]:
    # Highest realized PnL first; wallets without a realized figure go last.
    return (trader.realized_pnl_usd is None, -(trader.realized_pnl_usd or 0.0))


def write_traders_csv(path: Path, traders: list[Trader]) -> None:
    """Write traders ranked by realized PnL (re-sorted locally; gmgn_rank keeps GMGN's own order)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for rank, trader in enumerate(sorted(traders, key=_sort_key), start=1):
            writer.writerow(
                {
                    "rank": rank,
                    "wallet": _cell_text(trader.wallet),
                    "labels": _cell_text(";".join(trader.labels)),
                    "token_tags": _cell_text(";".join(trader.token_tags)),
                    "identity_name": _cell_text(trader.name),
                    "twitter": _cell_text(trader.twitter),
                    "wallet_type": trader.wallet_type,
                    "realized_pnl_usd": trader.realized_pnl_usd,
                    "unrealized_pnl_usd": trader.unrealized_pnl_usd,
                    "total_pnl_usd": trader.total_pnl_usd,
                    "realized_pnl_ratio": trader.realized_pnl_ratio,
                    "total_pnl_ratio": trader.total_pnl_ratio,
                    "invested_usd": trader.invested_usd,
                    "proceeds_usd": trader.proceeds_usd,
                    "total_cost_usd": trader.total_cost_usd,
                    "buy_volume_usd": trader.buy_volume_usd,
                    "sell_volume_usd": trader.sell_volume_usd,
                    "buys": trader.buys,
                    "sells": trader.sells,
                    "avg_buy_price": trader.avg_buy_price,
                    "avg_sell_price": trader.avg_sell_price,
                    "balance": trader.balance,
                    "value_usd": trader.value_usd,
                    "supply_ratio": trader.supply_ratio,
                    "first_hold_utc": _format_ts(trader.first_hold_ts),
                    "last_active_utc": _format_ts(trader.last_active_ts),
                    "exit_utc": _format_ts(trader.exit_ts),
                    "funded_by": _cell_text(trader.funded_by),
                    "transfer_in": "" if trader.transfer_in is None else str(trader.transfer_in).lower(),
                    "gmgn_rank": trader.gmgn_rank,
                }
            )
