"""GMGN OpenAPI adapter (https://openapi.gmgn.ai).

Fetches the top traders of ONE Solana token from GET /v1/market/token_top_traders.
Auth mode "exist" (same as the official gmgn-cli): X-APIKEY header plus a fresh
`timestamp` (unix seconds, server tolerance +-5s) and `client_id` (UUID, replays
are rejected within ~7s) query parameter on every request. No signature needed.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import re
import time
from typing import Callable, Protocol
import uuid

import requests

BASE_URL = "https://openapi.gmgn.ai"
TRADERS_PATH = "/v1/market/token_top_traders"
CHAIN = "sol"
TIMEOUT_SECONDS = 20
MAX_LIMIT = 100  # documented maximum per request; no pagination is documented
AUTO_RETRY_MAX_WAIT_SECONDS = 5  # same default as the official CLI
RETRY_BUFFER_SECONDS = 1
USER_AGENT = "gmgn-top-trader-cli/1.0"
MINT_PATTERN = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")
ORDER_BY_VALUES = ("amount_percentage", "profit", "unrealized_profit", "buy_volume_cur", "sell_volume_cur")
TAG_VALUES = ("smart_degen", "renowned", "fresh_wallet", "dev", "sniper", "rat_trader", "bundler", "transfer_in", "dex_bot", "bluechip_owner")


@dataclass(frozen=True)
class Trader:
    wallet: str
    gmgn_rank: int
    name: str | None
    twitter: str | None
    labels: list[str]
    token_tags: list[str]
    wallet_type: str
    realized_pnl_usd: float | None
    unrealized_pnl_usd: float | None
    total_pnl_usd: float | None
    realized_pnl_ratio: float | None
    total_pnl_ratio: float | None
    invested_usd: float | None
    proceeds_usd: float | None
    total_cost_usd: float | None
    buy_volume_usd: float | None
    sell_volume_usd: float | None
    buys: int | None
    sells: int | None
    avg_buy_price: float | None
    avg_sell_price: float | None
    balance: float | None
    value_usd: float | None
    supply_ratio: float | None
    first_hold_ts: int | None
    last_active_ts: int | None
    exit_ts: int | None
    funded_by: str | None
    transfer_in: bool | None


@dataclass(frozen=True)
class TokenTraders:
    traders: list[Trader]
    raw: dict


class Session(Protocol):
    def get(self, url: str, *, headers: dict[str, str], params: dict[str, object], timeout: int): ...


class GmgnError(Exception):
    """Base class for errors raised by the GMGN adapter."""


class GmgnApiError(GmgnError):
    def __init__(self, status_code: int, message: str, *, code: object = None, reset_at: int | None = None):
        self.status_code, self.code, self.reset_at = status_code, code, reset_at
        super().__init__(f"GMGN API error (HTTP {status_code}): {message}")


class GmgnResponseError(GmgnError):
    pass


class GmgnNetworkError(GmgnError):
    pass


def _dig(obj: object, *path: str) -> object:
    for key in path:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(key)
    return obj


def _num(value: object) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value.replace(",", "").lstrip("$"))
        except ValueError:
            return None
    return None


def _int(value: object) -> int | None:
    number = _num(value)
    return int(number) if number is not None else None


def _text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _strings(value: object) -> list[str]:
    return [item for item in value if isinstance(item, str) and item] if isinstance(value, list) else []


def _preview(row: object) -> str:
    return json.dumps(row, default=str)[:400]


class GmgnClient:
    def __init__(
        self,
        api_key: str,
        *,
        session: Session | None = None,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.time,
    ) -> None:
        if not api_key:
            raise ValueError("API key is required")
        self._api_key = api_key
        self._session = session or requests.Session()
        self._sleep = sleep
        self._clock = clock

    def fetch_token_traders(
        self,
        mint_address: str,
        limit: int = 100,
        *,
        order_by: str = "profit",
        direction: str = "desc",
        tag: str | None = None,
    ) -> TokenTraders:
        mint = mint_address.strip()
        if not MINT_PATTERN.match(mint):
            raise ValueError("Mint address is not a valid Solana address")
        if not 1 <= limit <= MAX_LIMIT:
            raise ValueError(f"Limit must be between 1 and {MAX_LIMIT} (GMGN returns at most {MAX_LIMIT} traders)")
        if order_by not in ORDER_BY_VALUES:
            raise ValueError(f"order-by must be one of: {', '.join(ORDER_BY_VALUES)}")
        if direction not in ("asc", "desc"):
            raise ValueError("direction must be asc or desc")
        if tag is not None and tag not in TAG_VALUES:
            raise ValueError(f"tag must be one of: {', '.join(TAG_VALUES)}")
        query: dict[str, object] = {"chain": CHAIN, "address": mint, "limit": limit, "order_by": order_by, "direction": direction}
        if tag:
            query["tag"] = tag
        data = self._get_data(TRADERS_PATH, query)
        rows = data.get("list") if isinstance(data, dict) else data if isinstance(data, list) else None
        if not isinstance(rows, list):
            keys = ", ".join(sorted(data)) if isinstance(data, dict) else type(data).__name__
            raise GmgnResponseError(f"GMGN response is missing a list of traders (got: {keys})")
        traders = [self._parse_trader(row, index) for index, row in enumerate(rows, start=1)]
        if traders and all(trader.realized_pnl_usd is None for trader in traders):
            raise GmgnResponseError(f"No trader row has realized_profit, so they cannot be ranked. First row: {_preview(rows[0])}")
        return TokenTraders(traders=traders, raw=data if isinstance(data, dict) else {"list": rows})

    def _get_data(self, path: str, query: dict[str, object]) -> object:
        url = f"{BASE_URL}{path}"
        headers = {"X-APIKEY": self._api_key, "Accept": "application/json", "User-Agent": USER_AGENT}
        for attempt in (1, 2):
            # Fresh timestamp + client_id on EVERY attempt: replayed client_ids are rejected.
            params = {**query, "timestamp": int(self._clock()), "client_id": str(uuid.uuid4())}
            try:
                response = self._session.get(url, headers=headers, params=params, timeout=TIMEOUT_SECONDS)
            except requests.RequestException as exc:
                raise GmgnNetworkError(f"Network error contacting GMGN: {exc}") from exc
            try:
                payload = response.json()
            except (ValueError, TypeError):
                payload = None
            status = response.status_code
            if isinstance(payload, dict) and payload.get("code") == 0 and status == 200:
                return payload.get("data")
            error = self._build_error(status, payload, response)
            wait = self._auto_retry_wait(error, attempt)
            if wait is None:
                raise error
            self._sleep(wait)
        raise GmgnError("GMGN request failed unexpectedly")

    def _build_error(self, status: int, payload: object, response: object) -> GmgnApiError:
        headers = getattr(response, "headers", None) or {}
        reset_at = None
        try:
            reset_at = int(headers.get("X-RateLimit-Reset"))
        except (TypeError, ValueError):
            pass
        if not isinstance(payload, dict):
            return GmgnApiError(status, "non-JSON response", reset_at=reset_at)
        reset_at = _int(payload.get("reset_at")) or reset_at
        parts = [str(payload[key]) for key in ("error", "message") if payload.get(key)]
        if payload.get("code") not in (None, 0):
            parts.insert(0, f"code={payload['code']}")
        if payload.get("upgrade_message"):
            parts.append(str(payload["upgrade_message"]))
        if status == 429 and reset_at:
            parts.append(f"rate limit resets at {self._format_local(reset_at)}; stop sending requests until then")
        return GmgnApiError(status, " ".join(parts) or "Request failed", code=payload.get("code"), reset_at=reset_at)

    def _auto_retry_wait(self, error: GmgnApiError, attempt: int) -> float | None:
        if attempt >= 2 or error.status_code != 429 or not error.reset_at:
            return None
        wait = max(error.reset_at - self._clock(), 0) + RETRY_BUFFER_SECONDS
        return wait if wait <= AUTO_RETRY_MAX_WAIT_SECONDS else None

    @staticmethod
    def _format_local(unix_seconds: int) -> str:
        from datetime import datetime

        return datetime.fromtimestamp(unix_seconds).astimezone().strftime("%H:%M:%S %Z")

    @staticmethod
    def _parse_trader(row: object, index: int) -> Trader:
        if not isinstance(row, dict):
            raise GmgnResponseError(f"Trader row {index} is not an object")
        wallet = _text(row.get("address"))
        if wallet is None:
            raise GmgnResponseError(f"Trader row {index} has no address (row keys: {', '.join(sorted(row))})")
        raw_realized = row.get("realized_profit")
        realized = _num(raw_realized)
        if raw_realized is not None and realized is None:
            raise GmgnResponseError(f"Trader row {index} has invalid realized_profit (value: {raw_realized!r}). Row: {_preview(row)}")
        transfer_in = row.get("transfer_in")
        balance = _num(row.get("balance") if row.get("balance") is not None else row.get("amount_cur"))
        return Trader(
            wallet=wallet,
            gmgn_rank=index,
            name=_text(row.get("name")) or _text(row.get("twitter_name")),
            twitter=_text(row.get("twitter_username")),
            labels=_strings(row.get("tags")),
            token_tags=_strings(row.get("maker_token_tags")),
            wallet_type="exchange_or_pool" if row.get("addr_type") == 2 else "wallet",
            realized_pnl_usd=realized,
            unrealized_pnl_usd=_num(row.get("unrealized_profit")),
            total_pnl_usd=_num(row.get("profit")),
            realized_pnl_ratio=_num(row.get("realized_pnl")),
            total_pnl_ratio=_num(row.get("profit_change")),
            invested_usd=_num(row.get("history_bought_cost")),
            proceeds_usd=_num(row.get("history_sold_income")),
            total_cost_usd=_num(row.get("total_cost")),
            buy_volume_usd=_num(row.get("buy_volume_cur")),
            sell_volume_usd=_num(row.get("sell_volume_cur")),
            buys=_int(row.get("buy_tx_count_cur")),
            sells=_int(row.get("sell_tx_count_cur")),
            avg_buy_price=_num(row.get("avg_cost")),
            avg_sell_price=_num(row.get("avg_sold")),
            balance=balance,
            value_usd=_num(row.get("usd_value")),
            supply_ratio=_num(row.get("amount_percentage")),
            first_hold_ts=_int(row.get("start_holding_at")),
            last_active_ts=_int(row.get("last_active_timestamp")),
            exit_ts=_int(row.get("end_holding_at")),
            funded_by=_text(_dig(row, "native_transfer", "address")),
            transfer_in=transfer_in if isinstance(transfer_in, bool) else None,
        )
