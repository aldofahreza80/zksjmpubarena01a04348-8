# gmgn-top-trader-cli

Exports the top traders of one Solana token from GMGN's official OpenAPI
(`GET https://openapi.gmgn.ai/v1/market/token_top_traders`, the same endpoint the official `gmgn-cli token traders` uses),
ranked by **realized PnL**, with GMGN's wallet tags (dev, sniper, smart_degen, renowned, bundler, dex_bot...) kept in the CSV.

Third tool next to `top-trader-cli` (Vybe) and `soltracker-top-trader-cli` (Solana Tracker). Each platform defines PnL
differently, so numbers will not match; that difference is the point of comparing them.

## Get an API key

1. Make an Ed25519 key pair. On Windows, Git for Windows ships openssl (usually `C:\Program Files\Git\usr\bin\openssl.exe`):
   ```powershell
   & "C:\Program Files\Git\usr\bin\openssl.exe" genpkey -algorithm ed25519 -out gmgn_private.pem
   & "C:\Program Files\Git\usr\bin\openssl.exe" pkey -in gmgn_private.pem -pubout
   ```
2. Log in at https://gmgn.ai/ai, paste the **public** key printed above into the API key form, and copy the API key it shows.
3. Keep `gmgn_private.pem` private. This tool does not need it (token endpoints only need the API key), so never put it in `.env` here.

## Run

```powershell
pip install -r requirements.txt
$env:GMGN_API_KEY = "your-api-key"     # or copy .env.example to .env
python main.py <mint> --raw
```

The key is also read from `~/.config/gmgn/.env`, the file the official gmgn-cli uses. CSV goes to
`output\gmgn_top_traders_<mint>_<UTC timestamp>.csv`.

## Options

| Option | Effect |
| --- | --- |
| `--limit N` | Traders to request, 1-100 (GMGN returns at most 100; no pagination is documented). |
| `--order-by` | How GMGN picks its top list: `profit` (default), `unrealized_profit`, `amount_percentage`, `buy_volume_cur`, `sell_volume_cur`. |
| `--direction` | `desc` (default) or `asc`. |
| `--tag` | Only wallets with this GMGN tag, e.g. `dev`, `sniper`, `smart_degen`, `renowned`, `bundler`. |
| `--raw` | Also save the raw API response as `.raw.json` next to the CSV. |

## Ranking caveat

GMGN can sort server-side by `profit`, `unrealized_profit`, volume or supply share, but not by `realized_profit`.
The tool asks GMGN for its top N by `profit`, then re-sorts those rows locally by `realized_profit`, which is what `rank` means.
`gmgn_rank` keeps GMGN's own position. On a token with more than 100 traders, a wallet with high realized but low total profit
may not be in GMGN's top 100 at all. The GMGN docs also describe `profit` both as realized profit (in the sort-field table) and as
realized + unrealized (in the response-field table), so check against `--raw` output.

## CSV columns

Names shared with the Solana Tracker CSV are identical: `wallet, labels, identity_name, realized_pnl_usd, unrealized_pnl_usd,
total_pnl_usd, invested_usd, proceeds_usd, buys, sells, balance, value_usd`.

GMGN-specific: `token_tags` (behavior on this token, e.g. `bundler`, `paper_hands`, `top_holder`), `twitter`, `wallet_type`
(`exchange_or_pool` for LP/exchange addresses), `realized_pnl_ratio` / `total_pnl_ratio` (ratios as GMGN returns them),
`total_cost_usd` (cost basis including fees), `buy_volume_usd`, `sell_volume_usd`, `avg_buy_price`, `avg_sell_price`,
`supply_ratio` (0-1, not percent), `first_hold_utc` / `last_active_utc` / `exit_utc`, `transfer_in` (holding was received by
transfer, not bought), `funded_by` (address of the wallet's first native SOL transfer; wallets sharing it likely share a funder),
`gmgn_rank`.

Text from the API is prefixed with `'` if it starts with `= + - @`, so Excel never runs it as a formula.

## If something fails

- **401/403 with a correct key**: GMGN only works over IPv4 (disable IPv6 on your network adapter) and the server allows only
  about 5 seconds of clock drift, so sync your Windows clock.
- **429**: the rate limit is shared across GMGN calls (traders cost 5 of a 20-point bucket). Short waits are retried once;
  longer ones print the exact reset time. Repeated requests during a ban can extend it up to 5 minutes.
- Tests: `python -m unittest discover`
