import csv
from pathlib import Path
import tempfile
import unittest

from csv_writer import CSV_COLUMNS, write_traders_csv
from gmgn import Trader


def trader(**overrides):
    base = dict(
        wallet="W1", gmgn_rank=1, name="Dev Dan", twitter="devdan", labels=["dev", "axiom"], token_tags=["top_holder"], wallet_type="wallet",
        realized_pnl_usd=12.5, unrealized_pnl_usd=3.0, total_pnl_usd=15.5, realized_pnl_ratio=0.125, total_pnl_ratio=0.15,
        invested_usd=100.0, proceeds_usd=112.5, total_cost_usd=100.5, buy_volume_usd=100.0, sell_volume_usd=112.5, buys=2, sells=3,
        avg_buy_price=0.001, avg_sell_price=0.002, balance=10.0, value_usd=2.5, supply_ratio=0.05,
        first_hold_ts=1_700_000_000, last_active_ts=1_700_000_100, exit_ts=None, funded_by="FUNDER1", transfer_in=False,
    )
    base.update(overrides)
    return Trader(**base)


def read(traders):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "nested" / "out.csv"
        write_traders_csv(path, traders)
        with path.open(newline="", encoding="utf-8") as handle:
            return list(csv.DictReader(handle))


class CsvWriterTests(unittest.TestCase):
    def test_columns_and_values(self):
        row = read([trader()])[0]
        self.assertEqual(list(row), CSV_COLUMNS)
        self.assertEqual((row["rank"], row["wallet"], row["labels"], row["token_tags"], row["identity_name"]), ("1", "W1", "dev;axiom", "top_holder", "Dev Dan"))
        self.assertEqual((row["first_hold_utc"], row["last_active_utc"], row["exit_utc"]), ("2023-11-14T22:13:20Z", "2023-11-14T22:15:00Z", ""))
        self.assertEqual((row["funded_by"], row["transfer_in"], row["gmgn_rank"]), ("FUNDER1", "false", "1"))

    def test_resorted_by_realized_pnl_and_gmgn_rank_kept(self):
        rows = read([trader(wallet="A", gmgn_rank=1, realized_pnl_usd=5.0), trader(wallet="B", gmgn_rank=2, realized_pnl_usd=50.0),
                     trader(wallet="C", gmgn_rank=3, realized_pnl_usd=None), trader(wallet="D", gmgn_rank=4, realized_pnl_usd=-9.0)])
        self.assertEqual([(r["rank"], r["wallet"], r["gmgn_rank"]) for r in rows], [("1", "B", "2"), ("2", "A", "1"), ("3", "D", "4"), ("4", "C", "3")])

    def test_none_values_are_blank(self):
        row = read([trader(unrealized_pnl_usd=None, transfer_in=None, funded_by=None, buys=None)])[0]
        self.assertEqual((row["unrealized_pnl_usd"], row["transfer_in"], row["funded_by"], row["buys"]), ("", "", "", ""))

    def test_formula_like_text_is_neutralised(self):
        row = read([trader(name="=HYPERLINK(\"http://x\")", labels=["+evil"], twitter="@x")])[0]
        self.assertEqual((row["identity_name"], row["labels"], row["twitter"]), ("'=HYPERLINK(\"http://x\")", "'+evil", "'@x"))

    def test_negative_numbers_stay_numeric(self):
        self.assertEqual(read([trader(realized_pnl_usd=-12.0)])[0]["realized_pnl_usd"], "-12.0")


if __name__ == "__main__":
    unittest.main()
