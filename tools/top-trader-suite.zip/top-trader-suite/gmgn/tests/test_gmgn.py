import unittest

import requests

from gmgn import GmgnApiError, GmgnClient, GmgnNetworkError, GmgnResponseError

MINT = "7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq"


class FakeResponse:
    def __init__(self, status_code, payload, headers=None):
        self.status_code, self._payload, self.headers = status_code, payload, headers or {}

    def json(self):
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


class FakeSession:
    def __init__(self, responses):
        self.responses, self.calls = iter(responses), []

    def get(self, url, *, headers, params, timeout):
        self.calls.append((url, headers, dict(params), timeout))
        response = next(self.responses)
        if isinstance(response, Exception):
            raise response
        return response


def row(address="W1", realized=12.5, **overrides):
    data = {
        "address": address, "account_address": "TA1", "addr_type": 0, "exchange": "",
        "balance": 10.0, "amount_cur": 10.0, "usd_value": 2.5, "amount_percentage": 0.05,
        "buy_volume_cur": 100.0, "sell_volume_cur": 112.5, "buy_tx_count_cur": 2, "sell_tx_count_cur": 3,
        "avg_cost": 0.001, "avg_sold": 0.002, "history_bought_cost": 100.0, "history_sold_income": 112.5, "total_cost": 100.5,
        "profit": 15.5, "profit_change": 0.15, "realized_profit": realized, "realized_pnl": 0.125, "unrealized_profit": 3.0,
        "transfer_in": False, "start_holding_at": 1_700_000_000, "end_holding_at": None, "last_active_timestamp": 1_700_000_100,
        "name": "Dev Dan", "twitter_username": "devdan", "tags": ["dev", "axiom"], "maker_token_tags": ["top_holder"],
        "native_transfer": {"name": "Funder", "address": "FUNDER1", "timestamp": 1, "tx_hash": "h", "type": "t"},
    }
    data.update(overrides)
    return data


def ok(rows):
    return FakeResponse(200, {"code": 0, "data": {"list": rows}})


def client(session, sleeps=None, now=1_700_000_000.0):
    return GmgnClient("secret", session=session, sleep=(sleeps.append if sleeps is not None else (lambda _: None)), clock=lambda: now)


class GmgnClientTests(unittest.TestCase):
    def test_request_config_and_row_parsing(self):
        session = FakeSession([ok([row()])])
        result = client(session).fetch_token_traders(MINT, 50, tag="dev")
        url, headers, params, timeout = session.calls[0]
        self.assertEqual(url, "https://openapi.gmgn.ai/v1/market/token_top_traders")
        self.assertEqual(headers["X-APIKEY"], "secret"); self.assertEqual(timeout, 20)
        self.assertEqual({k: params[k] for k in ("chain", "address", "limit", "order_by", "direction", "tag")},
                         {"chain": "sol", "address": MINT, "limit": 50, "order_by": "profit", "direction": "desc", "tag": "dev"})
        self.assertEqual(params["timestamp"], 1_700_000_000); self.assertEqual(len(params["client_id"]), 36)
        t = result.traders[0]
        self.assertEqual((t.wallet, t.gmgn_rank, t.name, t.twitter, t.labels, t.token_tags, t.wallet_type), ("W1", 1, "Dev Dan", "devdan", ["dev", "axiom"], ["top_holder"], "wallet"))
        self.assertEqual((t.realized_pnl_usd, t.unrealized_pnl_usd, t.total_pnl_usd, t.realized_pnl_ratio, t.total_pnl_ratio), (12.5, 3.0, 15.5, 0.125, 0.15))
        self.assertEqual((t.invested_usd, t.proceeds_usd, t.total_cost_usd, t.buy_volume_usd, t.sell_volume_usd, t.buys, t.sells), (100.0, 112.5, 100.5, 100.0, 112.5, 2, 3))
        self.assertEqual((t.avg_buy_price, t.avg_sell_price, t.balance, t.value_usd, t.supply_ratio), (0.001, 0.002, 10.0, 2.5, 0.05))
        self.assertEqual((t.first_hold_ts, t.last_active_ts, t.exit_ts, t.funded_by, t.transfer_in), (1_700_000_000, 1_700_000_100, None, "FUNDER1", False))

    def test_tag_omitted_when_not_given(self):
        session = FakeSession([ok([row()])])
        client(session).fetch_token_traders(MINT)
        self.assertNotIn("tag", session.calls[0][2]); self.assertEqual(session.calls[0][2]["limit"], 100)

    def test_numbers_as_strings_and_sparse_row(self):
        sparse = {"address": "W2", "realized_profit": "-3.5", "unrealized_profit": None, "tags": None, "native_transfer": None, "addr_type": 2}
        t = client(FakeSession([ok([sparse])])).fetch_token_traders(MINT).traders[0]
        self.assertEqual((t.realized_pnl_usd, t.unrealized_pnl_usd, t.labels, t.funded_by, t.wallet_type), (-3.5, None, [], None, "exchange_or_pool"))
        self.assertIsNone(t.first_hold_ts); self.assertIsNone(t.transfer_in)

    def test_balance_falls_back_to_amount_cur(self):
        t = client(FakeSession([ok([row(balance=None, amount_cur=7.0)])])).fetch_token_traders(MINT).traders[0]
        self.assertEqual(t.balance, 7.0)

    def test_name_falls_back_to_twitter_name(self):
        t = client(FakeSession([ok([row(name=None, twitter_name="Dan T")])])).fetch_token_traders(MINT).traders[0]
        self.assertEqual(t.name, "Dan T")

    def test_each_attempt_gets_fresh_client_id(self):
        session = FakeSession([FakeResponse(429, {"code": 429, "error": "RATE_LIMIT_EXCEEDED", "message": "slow", "reset_at": 1_700_000_002}), ok([row()])])
        sleeps = []
        client(session, sleeps).fetch_token_traders(MINT)
        self.assertEqual(len(session.calls), 2); self.assertNotEqual(session.calls[0][2]["client_id"], session.calls[1][2]["client_id"])
        self.assertEqual(sleeps, [3.0])

    def test_long_rate_limit_is_not_retried_and_shows_reset_time(self):
        session = FakeSession([FakeResponse(429, {"code": 429, "error": "RATE_LIMIT_BANNED", "message": "banned", "reset_at": 1_700_000_300})])
        with self.assertRaises(GmgnApiError) as ctx:
            client(session).fetch_token_traders(MINT)
        self.assertEqual(len(session.calls), 1); self.assertEqual(ctx.exception.reset_at, 1_700_000_300)
        self.assertIn("RATE_LIMIT_BANNED", str(ctx.exception)); self.assertIn("resets at", str(ctx.exception))

    def test_reset_header_used_when_body_has_none(self):
        session = FakeSession([FakeResponse(429, {"code": 429, "error": "RATE_LIMIT_EXCEEDED"}, {"X-RateLimit-Reset": "1700000001"}), ok([row()])])
        sleeps = []
        client(session, sleeps).fetch_token_traders(MINT)
        self.assertEqual(sleeps, [2.0])

    def test_second_429_is_final(self):
        body = {"code": 429, "error": "RATE_LIMIT_EXCEEDED", "reset_at": 1_700_000_001}
        session = FakeSession([FakeResponse(429, body), FakeResponse(429, body)])
        with self.assertRaises(GmgnApiError):
            client(session).fetch_token_traders(MINT)
        self.assertEqual(len(session.calls), 2)

    def test_api_error_with_http_200_but_nonzero_code(self):
        session = FakeSession([FakeResponse(200, {"code": 40001, "error": "INVALID_PARAM", "message": "bad order_by"})])
        with self.assertRaises(GmgnApiError) as ctx:
            client(session).fetch_token_traders(MINT)
        self.assertIn("code=40001", str(ctx.exception)); self.assertIn("bad order_by", str(ctx.exception))

    def test_http_401_and_non_json(self):
        with self.assertRaises(GmgnApiError) as ctx:
            client(FakeSession([FakeResponse(401, ValueError("not json"))])).fetch_token_traders(MINT)
        self.assertEqual(ctx.exception.status_code, 401); self.assertIn("non-JSON", str(ctx.exception))

    def test_network_error(self):
        with self.assertRaises(GmgnNetworkError):
            client(FakeSession([requests.ConnectionError("down")])).fetch_token_traders(MINT)

    def test_missing_list_reports_keys(self):
        with self.assertRaises(GmgnResponseError) as ctx:
            client(FakeSession([FakeResponse(200, {"code": 0, "data": {"rows": [], "oops": 1}})])).fetch_token_traders(MINT)
        self.assertIn("oops", str(ctx.exception))

    def test_row_without_address_reports_keys(self):
        with self.assertRaises(GmgnResponseError) as ctx:
            client(FakeSession([ok([{"foo": "bar"}])])).fetch_token_traders(MINT)
        self.assertIn("foo", str(ctx.exception))

    def test_invalid_realized_value_reports_row(self):
        with self.assertRaises(GmgnResponseError) as ctx:
            client(FakeSession([ok([row(realized={"x": 1})])])).fetch_token_traders(MINT)
        self.assertIn("realized_profit", str(ctx.exception))

    def test_all_realized_missing_is_an_error_with_preview(self):
        r = {"address": "W", "weird_profit": 1}
        with self.assertRaises(GmgnResponseError) as ctx:
            client(FakeSession([ok([r, r])])).fetch_token_traders(MINT)
        self.assertIn("weird_profit", str(ctx.exception))

    def test_input_validation_before_any_request(self):
        session = FakeSession([])
        c = client(session)
        for bad in ("", "short", "../../x", MINT + "/x"):
            with self.assertRaises(ValueError):
                c.fetch_token_traders(bad)
        for kwargs in ({"limit": 0}, {"limit": 101}, {"order_by": "realized"}, {"direction": "up"}, {"tag": "whale"}):
            with self.assertRaises(ValueError):
                c.fetch_token_traders(MINT, **kwargs)
        self.assertEqual(session.calls, [])

    def test_empty_list_is_ok(self):
        self.assertEqual(client(FakeSession([ok([])])).fetch_token_traders(MINT).traders, [])


if __name__ == "__main__":
    unittest.main()
