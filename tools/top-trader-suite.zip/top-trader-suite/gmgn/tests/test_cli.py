from contextlib import redirect_stderr, redirect_stdout
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import main
from gmgn import GmgnApiError, TokenTraders
from tests.test_csv_writer import trader

MINT = "7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq"


def run_cli(argv, env, fetch=None):
    out, err = io.StringIO(), io.StringIO()
    with mock.patch.dict(os.environ, env, clear=True), mock.patch.object(main, "load_env_file", lambda _p: None), \
            mock.patch.object(main, "utc_timestamp", lambda: "20261001_143025"), redirect_stdout(out), redirect_stderr(err):
        if fetch is not None:
            with mock.patch.object(main.GmgnClient, "fetch_token_traders", fetch):
                code = main.run(argv)
        else:
            code = main.run(argv)
    return code, out.getvalue(), err.getvalue()


class CliTests(unittest.TestCase):
    def test_success_creates_timestamped_csv_and_raw_json(self):
        calls = []

        def fetch(self, mint, limit, **kwargs):
            calls.append((mint, limit, kwargs))
            return TokenTraders([trader()], {"list": [{"address": "W1"}]})

        with tempfile.TemporaryDirectory() as directory, mock.patch.object(main, "OUTPUT_DIR", Path(directory)):
            code, out, err = run_cli([MINT, "--limit", "40", "--tag", "dev", "--order-by", "unrealized_profit", "--raw"], {"GMGN_API_KEY": "k"}, fetch)
            csv_path = Path(directory) / f"gmgn_top_traders_{MINT}_20261001_143025.csv"
            self.assertEqual(code, 0, err)
            self.assertTrue(csv_path.is_file())
            self.assertEqual(json.loads(csv_path.with_suffix(".raw.json").read_text()), {"list": [{"address": "W1"}]})
        self.assertEqual(calls, [(MINT, 40, {"order_by": "unrealized_profit", "direction": "desc", "tag": "dev"})])
        self.assertIn("(1 traders)", out)

    def test_missing_api_key(self):
        code, _out, err = run_cli([MINT], {})
        self.assertEqual(code, 1); self.assertIn("GMGN_API_KEY", err)

    def test_missing_mint_prints_usage(self):
        code, _out, err = run_cli([], {"GMGN_API_KEY": "k"})
        self.assertEqual(code, 2); self.assertIn("usage", err.lower())

    def test_auth_error_gets_ipv4_and_clock_hint(self):
        def fetch(self, *_a, **_k):
            raise GmgnApiError(403, "forbidden")
        code, _out, err = run_cli([MINT], {"GMGN_API_KEY": "k"}, fetch)
        self.assertEqual(code, 1); self.assertIn("403", err); self.assertIn("IPv4", err); self.assertIn("clock", err)

    def test_other_api_error_has_no_auth_hint(self):
        def fetch(self, *_a, **_k):
            raise GmgnApiError(429, "slow down")
        _code, _out, err = run_cli([MINT], {"GMGN_API_KEY": "k"}, fetch)
        self.assertNotIn("IPv4", err)

    def test_invalid_mint_is_a_clean_error(self):
        code, _out, err = run_cli(["not-a-mint"], {"GMGN_API_KEY": "k"})
        self.assertEqual(code, 1); self.assertIn("not a valid Solana address", err)

    def test_no_traders_is_an_error(self):
        code, _out, err = run_cli([MINT], {"GMGN_API_KEY": "k"}, lambda self, *_a, **_k: TokenTraders([], {}))
        self.assertEqual(code, 1); self.assertIn("no traders", err)

    def test_env_file_loader_does_not_override_real_env(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / ".env"
            path.write_text("# comment\nGMGN_API_KEY=\"from_file\"\nOTHER=1\n", encoding="utf-8")
            with mock.patch.dict(os.environ, {"OTHER": "real"}, clear=True):
                main.load_env_file(path)
                self.assertEqual(os.environ["GMGN_API_KEY"], "from_file"); self.assertEqual(os.environ["OTHER"], "real")


if __name__ == "__main__":
    unittest.main()
