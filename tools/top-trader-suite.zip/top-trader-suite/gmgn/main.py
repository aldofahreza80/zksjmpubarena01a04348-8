from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys

from csv_writer import write_traders_csv
from gmgn import ORDER_BY_VALUES, TAG_VALUES, GmgnApiError, GmgnClient, GmgnError

OUTPUT_DIR = Path("output")
ENV_VAR = "GMGN_API_KEY"
AUTH_HINT = (
    "Check GMGN_API_KEY (the API key, not the private key). GMGN only works over IPv4, so disable IPv6 if the key is correct, "
    "and make sure this PC's clock is accurate (the server allows about 5 seconds of drift)."
)


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def safe_mint_for_filename(mint: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", mint)


def load_env_file(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE lines). Real environment variables win."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Export a Solana token's top traders from GMGN, ranked by realized PnL (GMGN returns at most 100)."
    )
    parser.add_argument("mint", nargs="?", help="Solana token mint address")
    parser.add_argument("--limit", type=int, default=100, help="traders to request, 1-100 (default: 100)")
    parser.add_argument("--order-by", default="profit", choices=ORDER_BY_VALUES, help="how GMGN picks its top list (default: profit); the CSV is re-sorted by realized PnL")
    parser.add_argument("--direction", default="desc", choices=("asc", "desc"), help="sort direction for --order-by (default: desc)")
    parser.add_argument("--tag", choices=TAG_VALUES, help="only wallets with this GMGN tag (e.g. dev, sniper, smart_degen)")
    parser.add_argument("--raw", action="store_true", help="also save the raw API response as JSON next to the CSV")
    args = parser.parse_args(argv)
    if not args.mint:
        parser.print_usage(sys.stderr)
        return 2
    load_env_file(Path(__file__).parent / ".env")
    load_env_file(Path.home() / ".config" / "gmgn" / ".env")  # same place the official gmgn-cli reads
    api_key = os.environ.get(ENV_VAR)
    if not api_key:
        print(f"Error: {ENV_VAR} environment variable is required.", file=sys.stderr)
        return 1
    try:
        result = GmgnClient(api_key).fetch_token_traders(
            args.mint, args.limit, order_by=args.order_by, direction=args.direction, tag=args.tag
        )
        if not result.traders:
            print("Error: GMGN returned no traders for this token.", file=sys.stderr)
            return 1
        stem = f"gmgn_top_traders_{safe_mint_for_filename(args.mint.strip())}_{utc_timestamp()}"
        output_path = OUTPUT_DIR / f"{stem}.csv"
        write_traders_csv(output_path, result.traders)
        if args.raw:
            (OUTPUT_DIR / f"{stem}.raw.json").write_text(json.dumps(result.raw, indent=2), encoding="utf-8")
    except GmgnApiError as exc:
        print(f"Error: {exc}" + (f" {AUTH_HINT}" if exc.status_code in (401, 403) else ""), file=sys.stderr)
        return 1
    except (GmgnError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Created {output_path} ({len(result.traders)} traders)")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
