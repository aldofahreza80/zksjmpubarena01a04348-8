import unittest

from suite.combine import SourceData, combine
from suite.model import Row


def row(source, wallet, rank, realized, **kw):
    return Row(source=source, wallet=wallet, rank=rank, sheet_row=rank + 1, realized=realized, **kw)


def sources():
    vybe = SourceData("vybe", "Vybe", [row("vybe", "A", 1, 100.5, name="Dan"), row("vybe", "B", 2, 50.0)])
    st = SourceData("solanatracker", "SolanaTracker", [
        row("solanatracker", "A", 1, 110.0, labels=("kol",)), row("solanatracker", "D", 2, 70.0, labels=("developer",)), row("solanatracker", "B", 3, 20.0)])
    gmgn = SourceData("gmgn", "GMGN", [
        row("gmgn", "A", 1, 105.0, labels=("renowned",), funded_by="F1", name="GmgnDan"), row("gmgn", "D", 2, 72.0, labels=("dev",), funded_by="F1"),
        row("gmgn", "E", 3, 15.0, labels=("sniper",))])
    return [vybe, st, gmgn]


class CombineTests(unittest.TestCase):
    def setUp(self):
        self.out = {c.wallet: c for c in combine(sources())}

    def test_union_counts_order_and_names(self):
        self.assertEqual(list(self.out), ["A", "D", "B", "E"])
        self.assertEqual([self.out[w].n_sources for w in "ADBE"], [3, 2, 2, 1])
        self.assertEqual(self.out["A"].sources_text, "Vybe, SolanaTracker, GMGN")
        self.assertEqual(self.out["A"].name, "Dan")  # first non-empty in provider order
        self.assertEqual((self.out["A"].funded_by, self.out["B"].funded_by), ("F1", None))

    def test_spread_numbers(self):
        a = self.out["A"]
        self.assertAlmostEqual(a.spread_usd, 9.5); self.assertAlmostEqual(a.spread_pct, 9.5 / 110.0)
        self.assertIsNone(self.out["E"].spread_usd); self.assertIsNone(self.out["E"].spread_pct)

    def test_flag_needs_both_thresholds(self):
        self.assertFalse(self.out["A"].flag_spread)
        self.assertTrue(self.out["B"].flag_spread)  # 50 vs 20: $30 and 60%
        loose = {c.wallet: c for c in combine(sources(), spread_pct=0.05, spread_usd=5)}
        self.assertTrue(loose["A"].flag_spread)
        big_but_small_pct = [SourceData("vybe", "Vybe", [row("vybe", "X", 1, 1000.0)]), SourceData("gmgn", "GMGN", [row("gmgn", "X", 1, 1100.0)])]
        self.assertFalse(combine(big_but_small_pct)[0].flag_spread)  # $100 but only ~9%

    def test_opposite_signs_and_zero_denominator(self):
        pair = [SourceData("vybe", "Vybe", [row("vybe", "X", 1, 10.0), row("vybe", "Z", 2, 0.0)]),
                SourceData("gmgn", "GMGN", [row("gmgn", "X", 1, -10.0), row("gmgn", "Z", 2, 0.0)])]
        out = {c.wallet: c for c in combine(pair)}
        self.assertAlmostEqual(out["X"].spread_pct, 2.0)
        self.assertEqual((out["Z"].spread_usd, out["Z"].spread_pct, out["Z"].flag_spread), (0.0, None, False))

    def test_only_in(self):
        self.assertEqual((self.out["E"].only_in, self.out["A"].only_in), ("GMGN", ""))
        single = combine([SourceData("vybe", "Vybe", [row("vybe", "A", 1, 1.0)])])
        self.assertEqual(single[0].only_in, "")

    def test_role_disagreement_uses_a_common_vocabulary(self):
        self.assertEqual(self.out["A"].role_disagreement, "")  # kol / renowned agree, Vybe has no labels at all
        self.assertEqual(self.out["D"].role_disagreement, "")  # developer / dev agree
        srcs = sources()
        srcs[2].rows[0] = row("gmgn", "A", 1, 105.0, labels=("renowned", "sniper"))
        self.assertEqual({c.wallet: c for c in combine(srcs)}["A"].role_disagreement, "sniper (hanya GMGN)")

    def test_single_labeled_provider_cannot_disagree(self):
        srcs = [SourceData("vybe", "Vybe", [row("vybe", "A", 1, 1.0)]), SourceData("gmgn", "GMGN", [row("gmgn", "A", 1, 1.0, labels=("dev",))])]
        self.assertEqual(combine(srcs)[0].role_disagreement, "")

    def test_missing_realized_values(self):
        srcs = [SourceData("vybe", "Vybe", [row("vybe", "A", 1, None)]), SourceData("gmgn", "GMGN", [row("gmgn", "A", 1, 5.0)])]
        item = combine(srcs)[0]
        self.assertEqual((item.n_sources, item.spread_usd, item.best_realized), (2, None, 5.0))


if __name__ == "__main__":
    unittest.main()
