from datetime import datetime, timezone
from pathlib import Path
import tempfile
import unittest

from suite.adapters import AdapterError, read_csv_table, rows_from_table, unescape_cell
from tests.support import gmgn_csv, st_csv, vybe_csv


def table_from(text, bom=False):
    with tempfile.TemporaryDirectory() as d:
        path = Path(d) / "x.csv"
        path.write_bytes((("\ufeff" if bom else "") + text).encode("utf-8"))
        return read_csv_table(path)


class AdapterTests(unittest.TestCase):
    def test_unescape_only_undoes_the_writers_apostrophe(self):
        self.assertEqual(unescape_cell("'=EVIL()"), "=EVIL()")
        self.assertEqual(unescape_cell("'+1"), "+1")
        self.assertEqual(unescape_cell("'hello"), "'hello")
        self.assertEqual(unescape_cell("'"), "'")
        self.assertEqual(unescape_cell("plain"), "plain")

    def test_vybe_rows(self):
        header, table = table_from(vybe_csv())
        rows, warnings = rows_from_table("vybe", header, table)
        self.assertEqual(warnings, [])
        a, b, c = rows
        self.assertEqual((a.wallet, a.rank, a.sheet_row, a.name, a.labels, a.realized), ("WALLET_A", 1, 2, "Dan", ("kol",), 100.5))
        self.assertEqual((b.name, b.labels, b.realized, b.sheet_row), (None, (), 50.0, 3))
        self.assertEqual((c.name, c.realized, c.first_ts, c.last_ts), ("=EVIL()", -5.0, None, None))

    def test_solanatracker_rows(self):
        header, table = table_from(st_csv())
        rows, _ = rows_from_table("solanatracker", header, table)
        a = rows[0]
        self.assertEqual((a.labels, a.name, a.realized, a.unrealized, a.total, a.invested, a.proceeds, a.buys, a.sells),
                         (("kol", "axiom"), "Dan", 110.0, 4.0, 114.0, 20.0, 130.0, 2, 3))
        self.assertEqual(a.first_ts, datetime(2026, 10, 7, 10, 0, 0, tzinfo=timezone.utc))
        self.assertEqual(a.last_ts, datetime(2026, 10, 7, 10, 30, 0, tzinfo=timezone.utc))
        self.assertEqual((rows[1].buys, rows[1].unrealized), (0, None))

    def test_gmgn_rows(self):
        header, table = table_from(gmgn_csv())
        rows, _ = rows_from_table("gmgn", header, table)
        a = rows[0]
        self.assertEqual((a.labels, a.token_tags, a.wallet_type, a.funded_by, a.realized), (("renowned", "axiom"), ("top_holder",), "wallet", "FUNDER1", 105.0))
        self.assertEqual(a.last_ts, datetime(2026, 10, 7, 10, 31, 0, tzinfo=timezone.utc))

    def test_escaped_text_from_provider_writers_is_unescaped(self):
        header, table = table_from("rank,trader_address,name,labels,realized_pnl_usd\n1,W1,'=EVIL(),'+x,1\n")
        rows, _ = rows_from_table("vybe", header, table)
        self.assertEqual((rows[0].name, rows[0].labels), ("=EVIL()", ("+x",)))

    def test_missing_required_columns(self):
        header, table = table_from("rank,foo\n1,2\n")
        with self.assertRaises(AdapterError) as ctx:
            rows_from_table("vybe", header, table)
        self.assertIn("trader_address", str(ctx.exception)); self.assertIn("foo", str(ctx.exception))

    def test_invalid_or_non_finite_realized_is_an_error(self):
        for bad in ("abc", "nan", "inf"):
            header, table = table_from(f"rank,trader_address,name,labels,realized_pnl_usd\n1,W1,,,{bad}\n")
            with self.assertRaises(AdapterError) as ctx:
                rows_from_table("vybe", header, table)
            self.assertIn("baris 2", str(ctx.exception))

    def test_empty_realized_is_allowed(self):
        header, table = table_from("rank,trader_address,name,labels,realized_pnl_usd\n1,W1,,,\n")
        rows, _ = rows_from_table("vybe", header, table)
        self.assertIsNone(rows[0].realized)

    def test_duplicates_and_blank_wallets_are_skipped_with_warnings(self):
        header, table = table_from("rank,trader_address,name,labels,realized_pnl_usd\n1,W1,,,1\n2,W1,,,2\n3,,,,3\n4,W4,,,4\n")
        rows, warnings = rows_from_table("vybe", header, table)
        self.assertEqual([r.wallet for r in rows], ["W1", "W4"])
        self.assertEqual(len(warnings), 2); self.assertIn("duplikat", warnings[0]); self.assertIn("kosong", warnings[1])
        self.assertEqual(rows[1].sheet_row, 5)

    def test_blank_lines_are_dropped_and_rows_stay_consistent(self):
        header, table = table_from("rank,trader_address,name,labels,realized_pnl_usd\n\n1,W1,,,1\n,,,,\n2,W2,,,2\n")
        rows, _ = rows_from_table("vybe", header, table)
        self.assertEqual([(r.wallet, r.sheet_row) for r in rows], [("W1", 2), ("W2", 3)])
        self.assertEqual(len(table), 2)

    def test_bom_and_unknown_source_and_empty_file(self):
        header, table = table_from(vybe_csv(), bom=True)
        self.assertEqual(header[0], "rank")
        with self.assertRaises(AdapterError):
            rows_from_table("nope", header, table)
        with self.assertRaises(AdapterError):
            table_from("")


if __name__ == "__main__":
    unittest.main()
