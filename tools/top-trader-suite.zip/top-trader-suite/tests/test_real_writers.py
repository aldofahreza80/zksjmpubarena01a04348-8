"""Guards against schema drift: the REAL csv_writer of each provider produces the CSV, the adapter must read it."""
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from suite.adapters import read_csv_table, rows_from_table

ROOT = Path(__file__).resolve().parent.parent

SNIPPETS = {
    "vybe": '''
import sys
from pathlib import Path
from vybe import Trader
from csv_writer import write_traders_csv
write_traders_csv(Path(sys.argv[1]), [Trader("W1", "Dan", ["kol", "x"], 12.5), Trader("W2", None, [], -3.0)])
''',
    "solanatracker": '''
import sys
from pathlib import Path
from solanatracker import Trader
from csv_writer import write_traders_csv
def t(w, **k):
    base = dict(wallet=w, labels=["developer", "axiom"], identity_name="Dev Dan", realized_pnl_usd=12.5, unrealized_pnl_usd=3.0,
                total_pnl_usd=15.5, roi=0.125, invested_usd=100.0, proceeds_usd=112.5, buys=2, sells=3, first_trade_ms=1700000000000,
                last_trade_ms=1700000100000, hold_time_secs=100.0, balance=10.0, value_usd=2.5, wallet_realized_pnl_usd=1000.0,
                wallet_total_trades=250, wallet_tokens_traded=40)
    base.update(k)
    return Trader(**base)
write_traders_csv(Path(sys.argv[1]), [t("W1"), t("W2", realized_pnl_usd=-3.5, identity_name="=EVIL", labels=[])])
''',
    "gmgn": '''
import sys
from pathlib import Path
from gmgn import Trader
from csv_writer import write_traders_csv
def t(w, **k):
    base = dict(wallet=w, gmgn_rank=1, name="Dev Dan", twitter="devdan", labels=["dev", "axiom"], token_tags=["top_holder"], wallet_type="wallet",
                realized_pnl_usd=12.5, unrealized_pnl_usd=3.0, total_pnl_usd=15.5, realized_pnl_ratio=0.125, total_pnl_ratio=0.15,
                invested_usd=100.0, proceeds_usd=112.5, total_cost_usd=100.5, buy_volume_usd=100.0, sell_volume_usd=112.5, buys=2, sells=3,
                avg_buy_price=0.001, avg_sell_price=0.002, balance=10.0, value_usd=2.5, supply_ratio=0.05, first_hold_ts=1700000000,
                last_active_ts=1700000100, exit_ts=None, funded_by="FUNDER1", transfer_in=False)
    base.update(k)
    return Trader(**base)
write_traders_csv(Path(sys.argv[1]), [t("W1"), t("W2", gmgn_rank=2, realized_pnl_usd=-3.5, name="=EVIL", labels=[], wallet_type="exchange_or_pool")])
''',
}


def real_rows(key):
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "out.csv"
        done = subprocess.run([sys.executable, "-c", SNIPPETS[key], str(out)], cwd=str(ROOT / key), capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
        header, table = read_csv_table(out)
        rows, warnings = rows_from_table(key, header, table)
        return rows, warnings


class RealWriterTests(unittest.TestCase):
    def test_vybe(self):
        rows, warnings = real_rows("vybe")
        self.assertEqual(warnings, [])
        self.assertEqual((rows[0].wallet, rows[0].name, rows[0].labels, rows[0].realized, rows[0].rank), ("W1", "Dan", ("kol", "x"), 12.5, 1))
        self.assertEqual((rows[1].name, rows[1].realized, rows[1].sheet_row), (None, -3.0, 3))

    def test_solanatracker(self):
        rows, _ = real_rows("solanatracker")
        a, b = rows
        self.assertEqual((a.labels, a.name, a.realized, a.unrealized, a.total, a.invested, a.proceeds, a.buys, a.sells),
                         (("developer", "axiom"), "Dev Dan", 12.5, 3.0, 15.5, 100.0, 112.5, 2, 3))
        self.assertEqual(a.first_ts, datetime(2023, 11, 14, 22, 13, 20, tzinfo=timezone.utc))
        self.assertEqual((b.name, b.realized, b.labels), ("=EVIL", -3.5, ()))  # the writer's apostrophe was undone

    def test_gmgn(self):
        rows, _ = real_rows("gmgn")
        a, b = rows
        self.assertEqual((a.labels, a.token_tags, a.wallet_type, a.funded_by, a.realized, a.unrealized, a.total),
                         (("dev", "axiom"), ("top_holder",), "wallet", "FUNDER1", 12.5, 3.0, 15.5))
        self.assertEqual(a.last_ts, datetime(2023, 11, 14, 22, 15, 0, tzinfo=timezone.utc))
        self.assertEqual((b.name, b.wallet_type, b.realized), ("=EVIL", "exchange_or_pool", -3.5))


if __name__ == "__main__":
    unittest.main()
