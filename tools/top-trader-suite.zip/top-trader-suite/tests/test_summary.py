from datetime import datetime, timedelta, timezone
import unittest

from suite.combine import SourceData
from suite.model import Row
from suite.summary import LIST_LIMIT, spearman, summarize

SNAP = datetime(2026, 10, 7, 12, 0, 0, tzinfo=timezone.utc)


def row(source, wallet, rank, realized, **kw):
    return Row(source=source, wallet=wallet, rank=rank, sheet_row=rank + 1, realized=realized, **kw)


class SpearmanTests(unittest.TestCase):
    def test_perfect_and_inverse(self):
        self.assertAlmostEqual(spearman([1, 2, 3, 4, 5], [10, 20, 30, 40, 50]), 1.0)
        self.assertAlmostEqual(spearman([1, 2, 3, 4, 5], [5, 4, 3, 2, 1]), -1.0)

    def test_ties_and_degenerate_cases(self):
        self.assertAlmostEqual(spearman([1, 2, 2, 3, 4], [1, 2, 2, 3, 4]), 1.0)
        self.assertIsNone(spearman([1, 2, 3, 4], [1, 2, 3, 4]))  # fewer than 5 pairs
        self.assertIsNone(spearman([1, 1, 1, 1, 1], [1, 2, 3, 4, 5]))  # no variance


class SummaryTests(unittest.TestCase):
    def test_pair_stats_and_source_stats(self):
        t0 = SNAP - timedelta(minutes=30)
        a = SourceData("solanatracker", "SolanaTracker", [row("solanatracker", "W1", 1, 100.0, first_ts=t0, last_ts=SNAP - timedelta(minutes=5), labels=("kol",)),
                                                          row("solanatracker", "W2", 2, 50.0), row("solanatracker", "W3", 3, 10.0)])
        b = SourceData("gmgn", "GMGN", [row("gmgn", "W1", 1, 90.0), row("gmgn", "W3", 2, 10.0), row("gmgn", "W9", 3, 1.0)])
        summary = summarize([a, b], SNAP)
        pair = summary.pairs[0]
        self.assertEqual((pair.a_label, pair.b_label, pair.shared), ("SolanaTracker", "GMGN", 2))
        self.assertAlmostEqual(pair.median_abs_diff, 5.0)  # diffs 10 and 0
        self.assertAlmostEqual(pair.median_rel_diff, 0.05)  # 10/100 and 0
        self.assertIsNone(pair.spearman); self.assertIsNone(pair.top_overlap)  # too few shared wallets / rows
        st = summary.sources[0]
        self.assertEqual((st.rows, st.labeled_rows, st.first_ts, st.last_ts, st.hit_limit), (3, 1, t0, SNAP - timedelta(minutes=5), False))
        self.assertAlmostEqual(summary.token_age_hours, 0.5)

    def test_top_overlap_when_lists_are_long_enough(self):
        a = SourceData("vybe", "Vybe", [row("vybe", f"W{i}", i, 100.0 - i) for i in range(1, 16)])
        b = SourceData("gmgn", "GMGN", [row("gmgn", f"W{i}", i, 100.0 - i) for i in list(range(1, 6)) + list(range(11, 21))])
        pair = summarize([a, b], SNAP).pairs[0]
        self.assertEqual(pair.top_overlap, 5)
        self.assertEqual(pair.shared, 10)  # W1-5 and W11-15
        self.assertAlmostEqual(pair.spearman, 1.0)

    def test_notes(self):
        full = [row("gmgn", f"W{i}", i, float(i)) for i in range(1, LIST_LIMIT + 1)]
        notes = summarize([SourceData("gmgn", "GMGN", full)], SNAP).notes
        self.assertTrue(any("batas 100" in n for n in notes)); self.assertTrue(any("satu sumber" in n for n in notes))

    def test_age_note_only_when_vybe_is_involved_and_older_than_a_day(self):
        old = SNAP - timedelta(hours=30)
        st = SourceData("solanatracker", "SolanaTracker", [row("solanatracker", "W1", 1, 1.0, first_ts=old)])
        vy = SourceData("vybe", "Vybe", [row("vybe", "W1", 1, 1.0)])
        self.assertTrue(any("30.0 jam" in n for n in summarize([vy, st], SNAP).notes))
        self.assertFalse(any("jam" in n and "Vybe memakai" in n for n in summarize([st], SNAP).notes))

    def test_vybe_scope_note_when_numbers_disagree_wildly(self):
        wallets = [(f"W{i}", float(i * 10)) for i in range(1, 8)]
        vy = SourceData("vybe", "Vybe", [row("vybe", w, i, v * 5) for i, (w, v) in enumerate(wallets, 1)])
        gm = SourceData("gmgn", "GMGN", [row("gmgn", w, i, v) for i, (w, v) in enumerate(wallets, 1)])
        self.assertTrue(any("dihitung khusus untuk token ini" in n for n in summarize([vy, gm], SNAP).notes))
        similar = SourceData("gmgn", "GMGN", [row("gmgn", w, i, v * 5 * 1.01) for i, (w, v) in enumerate(wallets, 1)])
        self.assertFalse(any("dihitung khusus untuk token ini" in n for n in summarize([vy, similar], SNAP).notes))


if __name__ == "__main__":
    unittest.main()
