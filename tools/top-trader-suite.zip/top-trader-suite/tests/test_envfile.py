from pathlib import Path
import tempfile
import unittest

from suite.envfile import load_env_file


class EnvFileTests(unittest.TestCase):
    def test_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / ".env"
            path.write_bytes("\ufeff# comment\nA=1\n  B = \"two words\" \nexport C='x'\nnoequals\n=novalue\nD=a=b\n\n".encode("utf-8"))
            self.assertEqual(load_env_file(path), {"A": "1", "B": "two words", "C": "x", "D": "a=b"})

    def test_missing_file(self):
        self.assertEqual(load_env_file(Path("/definitely/not/here/.env")), {})


if __name__ == "__main__":
    unittest.main()
