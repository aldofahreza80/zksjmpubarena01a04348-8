"""Shared helpers: fake provider folders whose main.py behaves like a real provider CLI."""
import csv
import io
import json
import os
from pathlib import Path
from unittest import mock

FAKE_MAIN = r'''
import json, os, sys, time
from pathlib import Path

here = Path(__file__).parent
cfg = json.loads((here / "behavior.json").read_text(encoding="utf-8"))
Path("seen.json").write_text(json.dumps({
    "env_vars": {k: (k in os.environ) for k in ["VYBE_API_KEY", "SOLANATRACKER_API_KEY", "GMGN_API_KEY"]},
    "values": {k: os.environ.get(k) for k in ["VYBE_API_KEY", "SOLANATRACKER_API_KEY", "GMGN_API_KEY"]},
    "pythonutf8": os.environ.get("PYTHONUTF8"), "argv": sys.argv[1:],
}), encoding="utf-8")
mode = cfg.get("mode", "ok")
if mode == "slow":
    time.sleep(30)
if cfg.get("echo_key"):
    print("my key is", os.environ.get(cfg["echo_key"]))
if cfg.get("emoji"):
    print("Token \U0001F680\U0001F525 done")
if mode == "fail":
    print("Error: boom happened", file=sys.stderr)
    sys.exit(1)
out = Path("output")
out.mkdir(exist_ok=True)
if mode in ("ok", "crash_after_csv"):
    (out / "result.csv").write_text(cfg["csv"], encoding="utf-8")
if mode == "crash_after_csv":
    print("Error: crashed after writing", file=sys.stderr)
    sys.exit(1)
print("Created output/result.csv")
'''

VYBE_COLUMNS = ["rank", "trader_address", "name", "labels", "realized_pnl_usd"]
ST_COLUMNS = [
    "rank", "wallet", "labels", "identity_name", "realized_pnl_usd", "unrealized_pnl_usd", "total_pnl_usd", "roi", "invested_usd",
    "proceeds_usd", "buys", "sells", "first_trade_utc", "last_trade_utc", "hold_time_secs", "balance", "value_usd",
    "wallet_lifetime_realized_pnl_usd", "wallet_lifetime_trades", "wallet_tokens_traded",
]
GMGN_COLUMNS = [
    "rank", "wallet", "labels", "token_tags", "identity_name", "twitter", "wallet_type", "realized_pnl_usd", "unrealized_pnl_usd",
    "total_pnl_usd", "realized_pnl_ratio", "total_pnl_ratio", "invested_usd", "proceeds_usd", "total_cost_usd", "buy_volume_usd",
    "sell_volume_usd", "buys", "sells", "avg_buy_price", "avg_sell_price", "balance", "value_usd", "supply_ratio",
    "first_hold_utc", "last_active_utc", "exit_utc", "funded_by", "transfer_in", "gmgn_rank",
]
KEY_VARS = ("VYBE_API_KEY", "SOLANATRACKER_API_KEY", "GMGN_API_KEY")


def make_csv(columns, rows):
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buffer.getvalue()


def vybe_csv():
    return make_csv(VYBE_COLUMNS, [
        {"rank": 1, "trader_address": "WALLET_A", "name": "Dan", "labels": "kol", "realized_pnl_usd": 100.5},
        {"rank": 2, "trader_address": "WALLET_B", "realized_pnl_usd": 50},
        {"rank": 3, "trader_address": "WALLET_C", "name": "=EVIL()", "realized_pnl_usd": -5},
    ])


def st_csv():
    return make_csv(ST_COLUMNS, [
        {"rank": 1, "wallet": "WALLET_A", "labels": "kol;axiom", "identity_name": "Dan", "realized_pnl_usd": 110.0, "unrealized_pnl_usd": 4.0,
         "total_pnl_usd": 114.0, "invested_usd": 20, "proceeds_usd": 130, "buys": 2, "sells": 3,
         "first_trade_utc": "2026-10-07T10:00:00Z", "last_trade_utc": "2026-10-07T10:30:00Z"},
        {"rank": 2, "wallet": "WALLET_D", "labels": "developer", "realized_pnl_usd": 70.0, "buys": 0, "sells": 1,
         "first_trade_utc": "2026-10-07T10:05:00Z", "last_trade_utc": "2026-10-07T10:20:00Z"},
        {"rank": 3, "wallet": "WALLET_B", "realized_pnl_usd": 20.0},
    ])


def gmgn_csv():
    return make_csv(GMGN_COLUMNS, [
        {"rank": 1, "wallet": "WALLET_A", "labels": "renowned;axiom", "token_tags": "top_holder", "identity_name": "Dan", "wallet_type": "wallet",
         "realized_pnl_usd": 105.0, "unrealized_pnl_usd": 3.0, "total_pnl_usd": 108.0, "buys": 2, "sells": 3,
         "first_hold_utc": "2026-10-07T10:00:00Z", "last_active_utc": "2026-10-07T10:31:00Z", "funded_by": "FUNDER1", "transfer_in": "false", "gmgn_rank": 2},
        {"rank": 2, "wallet": "WALLET_D", "labels": "dev", "wallet_type": "wallet", "realized_pnl_usd": 72.0, "buys": 0, "sells": 1,
         "first_hold_utc": "2026-10-07T10:04:00Z", "last_active_utc": "2026-10-07T10:21:00Z", "funded_by": "FUNDER1", "gmgn_rank": 1},
        {"rank": 3, "wallet": "WALLET_E", "labels": "sniper", "wallet_type": "wallet", "realized_pnl_usd": 15.0, "gmgn_rank": 3},
    ])


def write_fake_provider(root: Path, folder: str, **behavior):
    directory = Path(root) / folder
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "main.py").write_text(FAKE_MAIN, encoding="utf-8")
    (directory / "behavior.json").write_text(json.dumps(behavior), encoding="utf-8")


def clean_env(**extra):
    """Patch os.environ so the three key variables are absent unless given in `extra`."""
    env = {k: v for k, v in os.environ.items() if k not in KEY_VARS}
    env.update(extra)
    return mock.patch.dict(os.environ, env, clear=True)
