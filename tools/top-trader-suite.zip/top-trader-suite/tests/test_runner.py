import json
from pathlib import Path
import tempfile
import unittest

from suite.providers import PROVIDERS
from suite.runner import RunResult, build_child_env, last_line, redact, run_provider, run_providers, tail
from tests.support import KEY_VARS, clean_env, make_csv, vybe_csv, write_fake_provider

SPEC = {s.key: s for s in PROVIDERS}
KEYS = {"VYBE_API_KEY": "vybe-secret-111", "SOLANATRACKER_API_KEY": "st-secret-222", "GMGN_API_KEY": "gmgn-secret-333"}
MINT = "7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq"


def run_one(root, key="vybe", timeout=20, keys=None, raw_json=True):
    return run_provider(
        SPEC[key], provider_dir=Path(root) / SPEC[key].folder, mint=MINT, work_dir=Path(root) / "work", keys=KEYS if keys is None else keys,
        all_env_vars=KEY_VARS, timeout=timeout, raw_json=raw_json,
    )


class HelperTests(unittest.TestCase):
    def test_redact_and_tail_and_last_line(self):
        self.assertEqual(redact("token abcdef123 and abc", ["abcdef123", "abc", ""]), "token *** and abc")
        self.assertEqual(tail("x" * 20, 5), "[dipotong] ...xxxxx")
        self.assertEqual(last_line("a\n\n  b  \n\n"), "b")
        self.assertEqual(last_line(""), "")

    def test_child_env_only_has_own_key(self):
        env = build_child_env(SPEC["gmgn"], KEYS, KEY_VARS, {"PATH": "p", "VYBE_API_KEY": "leak", "GMGN_API_KEY": "old"})
        self.assertEqual(env["GMGN_API_KEY"], "gmgn-secret-333")
        self.assertNotIn("VYBE_API_KEY", env); self.assertNotIn("SOLANATRACKER_API_KEY", env)
        self.assertEqual((env["PATH"], env["PYTHONUTF8"], env["PYTHONIOENCODING"]), ("p", "1", "utf-8"))


class RunProviderTests(unittest.TestCase):
    def test_ok_run_collects_csv_and_isolates_env(self):
        with tempfile.TemporaryDirectory() as d, clean_env(GMGN_API_KEY="leaky-parent-value"):
            write_fake_provider(d, "vybe", mode="ok", csv=vybe_csv())
            result = run_one(d)
            self.assertEqual((result.status, result.returncode), ("ok", 0))
            self.assertEqual(result.csv_path.name, "result.csv"); self.assertEqual(result.csv_path.parent.parent, Path(d) / "work" / "vybe")
            seen = json.loads((Path(d) / "work" / "vybe" / "seen.json").read_text())
            self.assertEqual(seen["env_vars"], {"VYBE_API_KEY": True, "SOLANATRACKER_API_KEY": False, "GMGN_API_KEY": False})
            self.assertEqual((seen["pythonutf8"], seen["argv"]), ("1", [MINT]))
            self.assertIsNotNone(result.started); self.assertGreaterEqual(result.elapsed, 0)

    def test_raw_flag_passed_only_to_providers_that_support_it(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="ok", csv=vybe_csv()); write_fake_provider(d, "gmgn", mode="ok", csv=vybe_csv())
            run_one(d, "vybe"); run_one(d, "gmgn"); run_one(d, "gmgn", raw_json=False)
            self.assertEqual(json.loads((Path(d) / "work/vybe/seen.json").read_text())["argv"], [MINT])
            result = run_one(d, "gmgn")
            self.assertEqual(result.command[-2:], [MINT, "--raw"])

    def test_missing_key_is_skipped_without_running(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "gmgn", mode="ok", csv="x")
            result = run_one(d, "gmgn", keys={"VYBE_API_KEY": "only-vybe-key"})
            self.assertEqual(result.status, "skipped"); self.assertIn("GMGN_API_KEY", result.note)
            self.assertFalse((Path(d) / "work").exists())

    def test_missing_main_py_is_an_error(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            result = run_one(d)
            self.assertEqual(result.status, "error"); self.assertIn("main.py", result.note)

    def test_nonzero_exit_is_failed_with_last_error_line(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="fail")
            result = run_one(d)
            self.assertEqual((result.status, result.returncode, result.note), ("failed", 1, "Error: boom happened"))
            self.assertIsNone(result.csv_path)

    def test_csv_from_a_crashed_run_is_not_trusted(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="crash_after_csv", csv=vybe_csv())
            result = run_one(d)
            self.assertEqual(result.status, "failed"); self.assertIsNone(result.csv_path); self.assertIn("tidak dipakai", result.note)

    def test_exit_zero_without_csv_is_failed(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="no_csv")
            result = run_one(d)
            self.assertEqual(result.status, "failed"); self.assertIn("tanpa membuat CSV", result.note)

    def test_timeout_kills_the_process(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="slow")
            result = run_one(d, timeout=1)
            self.assertEqual(result.status, "timeout"); self.assertIn("1", result.note); self.assertLess(result.elapsed, 15)

    def test_keys_are_redacted_and_emoji_survives(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="ok", csv=vybe_csv(), echo_key="VYBE_API_KEY", emoji=True)
            result = run_one(d)
            self.assertEqual(result.status, "ok")
            self.assertIn("my key is ***", result.stdout); self.assertNotIn("vybe-secret-111", result.stdout)
            self.assertIn("\U0001F680", result.stdout)


class RunProvidersTests(unittest.TestCase):
    def test_parallel_run_keeps_order_and_isolates_failures(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="ok", csv=vybe_csv())
            write_fake_provider(d, "solanatracker", mode="fail")
            write_fake_provider(d, "gmgn", mode="ok", csv=vybe_csv())
            done = []
            results = run_providers(list(PROVIDERS), root=Path(d), mint=MINT, work_dir=Path(d) / "work", keys=KEYS, all_env_vars=KEY_VARS,
                                    timeout=20, on_done=lambda r: done.append(r.spec.key))
            self.assertEqual([r.spec.key for r in results], ["vybe", "solanatracker", "gmgn"])
            self.assertEqual([r.status for r in results], ["ok", "failed", "ok"])
            self.assertEqual(sorted(done), ["gmgn", "solanatracker", "vybe"])

    def test_internal_error_in_one_job_does_not_hide_the_rest(self):
        with tempfile.TemporaryDirectory() as d, clean_env():
            write_fake_provider(d, "vybe", mode="ok", csv=vybe_csv())
            results = run_providers([SPEC["vybe"], SPEC["gmgn"]], root=Path(d), mint=MINT, work_dir=Path(d) / "work", keys=KEYS,
                                    all_env_vars=KEY_VARS, timeout=20, python="/definitely/not/a/python")
            self.assertEqual([r.status for r in results], ["error", "error"])


if __name__ == "__main__":
    unittest.main()
