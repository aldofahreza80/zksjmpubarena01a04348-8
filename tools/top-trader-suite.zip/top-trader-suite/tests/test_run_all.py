import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

from openpyxl import load_workbook

import run_all
from tests.support import clean_env, gmgn_csv, st_csv, vybe_csv, write_fake_provider

MINT = "7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq"
ENV = "VYBE_API_KEY=vybe-secret-111\nSOLANATRACKER_API_KEY=st-secret-222\nGMGN_API_KEY=gmgn-secret-333\n"


def setup_root(d, vybe=None, st=None, gmgn=None, env=ENV):
    root = Path(d)
    write_fake_provider(root, "vybe", **(vybe or dict(mode="ok", csv=vybe_csv())))
    write_fake_provider(root, "solanatracker", **(st or dict(mode="ok", csv=st_csv())))
    write_fake_provider(root, "gmgn", **(gmgn or dict(mode="ok", csv=gmgn_csv())))
    if env is not None:
        (root / ".env").write_text(env, encoding="utf-8")
    return root


def run_cli(argv, root, **env):
    out, err = io.StringIO(), io.StringIO()
    with clean_env(**env), contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = run_all.run(argv, root=root, python=sys.executable)
    return code, out.getvalue(), err.getvalue()


def only(path_glob):
    found = sorted(path_glob)
    assert len(found) == 1, found
    return found[0]


class RunAllTests(unittest.TestCase):
    def test_happy_path_creates_one_workbook_and_an_archive(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 0, err)
            workbook = only((root / "output").glob("*.xlsx"))
            self.assertTrue(workbook.name.startswith(MINT[:8] + "_"))
            self.assertEqual(load_workbook(workbook).sheetnames, ["Ringkasan", "Gabungan", "Vybe", "SolanaTracker", "GMGN", "Log"])
            archive = only((root / "output" / "_raw").iterdir())
            manifest = json.loads((archive / "run.json").read_text(encoding="utf-8"))
            self.assertEqual([s["status"] for s in manifest["sources"]], ["ok", "ok", "ok"])
            self.assertEqual([s["rows"] for s in manifest["sources"]], [3, 3, 3])
            self.assertEqual(manifest["workbook"], str(workbook))
            self.assertTrue((archive / "vybe" / "output" / "result.csv").is_file())
            self.assertIn("5 wallet unik dari 3 sumber", out)
            self.assertNotIn("secret", out + err + (archive / "run.json").read_text(encoding="utf-8"))

    def test_each_provider_gets_only_its_own_key_from_the_root_env(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            self.assertEqual(run_cli([MINT], root)[0], 0)
            archive = only((root / "output" / "_raw").iterdir())
            for key, var in (("vybe", "VYBE_API_KEY"), ("solanatracker", "SOLANATRACKER_API_KEY"), ("gmgn", "GMGN_API_KEY")):
                seen = json.loads((archive / key / "seen.json").read_text())
                self.assertEqual({k for k, v in seen["env_vars"].items() if v}, {var})

    def test_real_environment_overrides_root_env_file(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            self.assertEqual(run_cli([MINT], root, VYBE_API_KEY="from-the-environment")[0], 0)
            archive = only((root / "output" / "_raw").iterdir())
            self.assertEqual(json.loads((archive / "vybe" / "seen.json").read_text())["values"]["VYBE_API_KEY"], "from-the-environment")
            self.assertEqual(json.loads((archive / "gmgn" / "seen.json").read_text())["values"]["GMGN_API_KEY"], "gmgn-secret-333")

    def test_one_failing_source_does_not_stop_the_others(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, st=dict(mode="fail"))
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 0, err)
            self.assertIn("1 sumber tidak ikut", out)
            wb = load_workbook(only((root / "output").glob("*.xlsx")))
            self.assertIn("Tidak ada data", wb["SolanaTracker"]["A1"].value)
            manifest = json.loads((only((root / "output" / "_raw").iterdir()) / "run.json").read_text(encoding="utf-8"))
            self.assertEqual([s["status"] for s in manifest["sources"]], ["ok", "failed", "ok"])

    def test_unreadable_csv_marks_that_source_failed_and_continues(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, gmgn=dict(mode="ok", csv="rank,foo\n1,2\n"))
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 0)
            self.assertIn("CSV tidak bisa dibaca", err)
            manifest = json.loads((only((root / "output" / "_raw").iterdir()) / "run.json").read_text(encoding="utf-8"))
            self.assertEqual([s["status"] for s in manifest["sources"]], ["ok", "ok", "failed"])
            self.assertIn("wallet", manifest["sources"][2]["adapter_error"])

    def test_all_failing_creates_no_workbook_but_keeps_evidence_and_returns_1(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, vybe=dict(mode="fail"), st=dict(mode="fail"), gmgn=dict(mode="fail"))
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 1)
            self.assertEqual(list((root / "output").glob("*.xlsx")), [])
            manifest = json.loads((only((root / "output" / "_raw").iterdir()) / "run.json").read_text(encoding="utf-8"))
            self.assertIsNone(manifest["workbook"])
            self.assertIn("boom happened", err)

    def test_missing_keys_are_skipped_not_run(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, env="GMGN_API_KEY=gmgn-secret-333\n")
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 0, err)
            archive = only((root / "output" / "_raw").iterdir())
            self.assertFalse((archive / "vybe").exists()); self.assertTrue((archive / "gmgn" / "output" / "result.csv").is_file())
            self.assertIn("dilewati", out)

    def test_no_keys_at_all_returns_1(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, env=None)
            code, out, err = run_cli([MINT], root)
            self.assertEqual(code, 1); self.assertIn("VYBE_API_KEY", err)

    def test_only_option_selects_providers(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            code, out, err = run_cli([MINT, "--only", "vybe, gmgn"], root)
            self.assertEqual(code, 0, err)
            archive = only((root / "output" / "_raw").iterdir())
            self.assertTrue((archive / "vybe").exists() and (archive / "gmgn").exists()); self.assertFalse((archive / "solanatracker").exists())
            wb = load_workbook(only((root / "output").glob("*.xlsx")))
            self.assertIn("Tidak ada data", wb["SolanaTracker"]["A1"].value)  # sheet exists, clearly empty

    def test_argument_errors(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            self.assertEqual(run_cli([], root)[0], 2)
            code, _out, err = run_cli(["not-a-mint"], root)
            self.assertEqual(code, 1); self.assertIn("bukan alamat Solana", err)
            code, _out, err = run_cli([MINT, "--only", "vybe,nope"], root)
            self.assertEqual(code, 2); self.assertIn("nope", err)
            self.assertEqual(run_cli([MINT, "--spread-usd", "-1"], root)[0], 2)
            self.assertFalse((root / "output").exists())  # nothing was started

    def test_timeout_option_is_applied(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, vybe=dict(mode="slow"))
            code, out, err = run_cli([MINT, "--timeout", "1"], root)
            self.assertEqual(code, 0, err)
            manifest = json.loads((only((root / "output" / "_raw").iterdir()) / "run.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["sources"][0]["status"], "timeout")

    def test_thresholds_are_passed_to_the_workbook(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d)
            self.assertEqual(run_cli([MINT, "--spread-usd", "3", "--spread-pct", "5"], root)[0], 0)
            ws = load_workbook(only((root / "output").glob("*.xlsx")))["Ringkasan"]
            values = {ws[f"A{r}"].value: ws[f"B{r}"].value for r in range(1, 30)}
            self.assertEqual((values["Ambang selisih realized (USD) >="], values["Ambang selisih relatif >="]), (3.0, 0.05))

    def test_emoji_in_provider_output_is_kept(self):
        with tempfile.TemporaryDirectory() as d:
            root = setup_root(d, st=dict(mode="ok", csv=st_csv(), emoji=True))
            self.assertEqual(run_cli([MINT], root)[0], 0)
            log = load_workbook(only((root / "output").glob("*.xlsx")))["Log"]
            self.assertIn("\U0001F680", "\n".join(str(c.value) for row in log.iter_rows() for c in row if c.value))


if __name__ == "__main__":
    unittest.main()
