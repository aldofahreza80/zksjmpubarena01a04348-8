from datetime import datetime, timedelta, timezone
from pathlib import Path
import re
import tempfile
import unittest

from openpyxl import load_workbook

from suite.adapters import read_csv_table, rows_from_table
from suite.combine import SourceData, combine
from suite.providers import PROVIDERS
from suite.runner import RunResult
from suite.summary import summarize
from suite.workbook import RunInfo, gabungan_columns, safe_text, write_workbook
from tests.support import gmgn_csv, st_csv, vybe_csv

SNAP = datetime(2026, 10, 7, 12, 0, 0, tzinfo=timezone.utc)
SPEC = {s.key: s for s in PROVIDERS}


def load_source(key, csv_text, tmp):
    path = Path(tmp) / f"{key}.csv"
    path.write_text(csv_text, encoding="utf-8")
    header, table = read_csv_table(path)
    rows, warnings = rows_from_table(key, header, table)
    return SourceData(key, SPEC[key].label, rows, warnings), (header, table)


def build(path, tmp, keys=("vybe", "solanatracker", "gmgn"), failed=(), extra_rows=None):
    csvs = {"vybe": vybe_csv(), "solanatracker": st_csv(), "gmgn": gmgn_csv()}
    sources, tables, results = [], {}, []
    for spec in PROVIDERS:
        base = dict(spec=spec, started=SNAP, ended=SNAP + timedelta(seconds=3), command=["python", "main.py", "MINT"], cwd=Path(tmp) / spec.key)
        if spec.key in keys and spec.key not in failed:
            data, table = load_source(spec.key, csvs[spec.key], tmp)
            if extra_rows and spec.key in extra_rows:
                data.rows.extend(extra_rows[spec.key])
            sources.append(data); tables[spec.key] = table
            results.append(RunResult(status="ok", returncode=0, stdout="Created output/result.csv", csv_path=Path(tmp) / f"{spec.key}.csv", **base))
        elif spec.key in failed:
            results.append(RunResult(status="failed", returncode=1, note="Error: boom happened", stderr="Error: boom happened", **base))
    info = RunInfo(mint="7bC8ugu1ZJn21MhA4ht483nX8brLNesa8R7XLimpFyhq", snapshot=SNAP, spread_usd=10.0, spread_pct=0.25, timeout=120, raw_json=True,
                   requested=[r.spec.label for r in results])
    combined = combine(sources, spread_pct=info.spread_pct, spread_usd=info.spread_usd)
    write_workbook(path, info=info, specs=list(PROVIDERS), results=results, sources=sources, tables=tables, combined=combined,
                   summary=summarize(sources, SNAP), fingerprints={"vybe": [("main.py", "abc123")]})
    return combined


def sheet_text(ws):
    return "\n".join(str(c.value) for row in ws.iter_rows() for c in row if c.value is not None)


class WorkbookTests(unittest.TestCase):
    def test_structure_columns_and_formulas(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            combined = build(path, d)
            wb = load_workbook(path)
            self.assertEqual(wb.sheetnames, ["Ringkasan", "Gabungan", "Vybe", "SolanaTracker", "GMGN", "Log"])
            self.assertTrue(wb.calculation.fullCalcOnLoad)
            gab = wb["Gabungan"]
            columns = gabungan_columns(list(PROVIDERS))
            self.assertEqual([c.value for c in gab[1]], columns)
            letter = {name: chr(ord("A") + i) for i, name in enumerate(columns)}
            self.assertEqual(gab.max_row, len(combined) + 1)
            first = {name: gab[f"{letter[name]}2"].value for name in columns}
            self.assertEqual(first["wallet"], "WALLET_A")
            self.assertEqual((first["rank_vybe"], first["rank_solanatracker"], first["rank_gmgn"]), (1, 1, 1))
            self.assertEqual((first["realized_vybe"], first["realized_solanatracker"], first["realized_gmgn"]), (100.5, 110.0, 105.0))
            self.assertEqual(first["n_sources"], "=COUNT(E2:G2)")
            self.assertEqual(first["spread_usd"], '=IF(COUNT(H2:J2)>=2,MAX(H2:J2)-MIN(H2:J2),"")')
            self.assertEqual((first["funded_by_gmgn"], first["sheet_row_vybe"], first["sheet_row_gmgn"]), ("FUNDER1", 2, 2))
            # thresholds live in Ringkasan and the flag formulas point at exactly those cells
            refs = re.findall(r"Ringkasan!\$B\$(\d+)", first["flag_spread"])
            self.assertEqual(len(refs), 2)
            rk = wb["Ringkasan"]
            self.assertEqual((rk[f"B{refs[0]}"].value, rk[f"B{refs[1]}"].value), (10.0, 0.25))
            self.assertEqual(rk[f"A{refs[0]}"].value, "Ambang selisih realized (USD) >=")

    def test_fonts_are_arial_everywhere(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d)
            wb = load_workbook(path)
            for ws in wb.worksheets:
                for row in ws.iter_rows():
                    for cell in row:
                        if cell.value is not None:
                            self.assertEqual(cell.font.name, "Arial", f"{ws.title}!{cell.coordinate}")

    def test_formula_like_text_is_neutralised_everywhere(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d)
            wb = load_workbook(path)
            names = {r[0].value: r[1].value for r in wb["Gabungan"].iter_rows(min_row=2)}
            self.assertEqual(names["WALLET_C"], "'=EVIL()")
            vybe = wb["Vybe"]
            self.assertEqual(vybe["C4"].value, "'=EVIL()")
            for ws in wb.worksheets:
                for row in ws.iter_rows():
                    for cell in row:
                        if isinstance(cell.value, str) and cell.value.startswith("="):
                            self.assertIn(cell.data_type, ("f",), cell.coordinate)  # only intentional formulas start with =
            self.assertEqual(safe_text("-5 abc"), "'-5 abc"); self.assertEqual(safe_text("a\x00b"), "ab")

    def test_raw_sheets_keep_csv_content_with_numbers_as_numbers(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d)
            wb = load_workbook(path)
            vy = wb["Vybe"]
            self.assertEqual([c.value for c in vy[1]], ["rank", "trader_address", "name", "labels", "realized_pnl_usd"])
            self.assertEqual((vy["A2"].value, vy["B2"].value, vy["E2"].value, vy["E4"].value), (1, "WALLET_A", 100.5, -5))
            self.assertIsInstance(vy["A2"].value, int)
            self.assertEqual(vy["E2"].number_format, "#,##0.00")
            gm = wb["GMGN"]
            header = [c.value for c in gm[1]]
            row2 = dict(zip(header, [c.value for c in gm[2]]))
            self.assertEqual((row2["wallet"], row2["transfer_in"], row2["funded_by"], row2["first_hold_utc"]), ("WALLET_A", "false", "FUNDER1", "2026-10-07T10:00:00Z"))
            self.assertIsNone(row2["exit_utc"])
            self.assertEqual(vy.freeze_panes, "A2"); self.assertEqual(vy.auto_filter.ref, "A1:E4")

    def test_failed_source_gets_a_note_sheet_and_is_listed(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d, failed=("solanatracker",))
            wb = load_workbook(path)
            st = wb["SolanaTracker"]
            self.assertIn("Tidak ada data", st["A1"].value); self.assertIn("gagal", st["A2"].value); self.assertIn("boom happened", st["A3"].value)
            text = sheet_text(wb["Ringkasan"])
            self.assertIn("gagal", text); self.assertIn("2 dari 3", text)
            self.assertIn("boom happened", sheet_text(wb["Log"]))
            gab = wb["Gabungan"]
            self.assertIsNone(gab["F2"].value)  # rank_solanatracker blank everywhere
            self.assertTrue(all(gab[f"F{r}"].value is None for r in range(2, gab.max_row + 1)))

    def test_single_source_has_no_comparison_sections(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d, keys=("gmgn",))
            text = sheet_text(load_workbook(path)["Ringkasan"])
            self.assertNotIn("Cakupan wallet", text); self.assertNotIn("Kecocokan realized", text)
            self.assertIn("Hanya satu sumber", text)

    def test_ringkasan_coverage_formulas_reference_the_right_ranges(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            combined = build(path, d)
            n = len(combined) + 1
            formulas = [c.value for row in load_workbook(path)["Ringkasan"].iter_rows() for c in row if isinstance(c.value, str) and c.value.startswith("=")]
            self.assertIn(f"=COUNTA(Gabungan!$A$2:$A${n})", formulas)
            self.assertIn(f"=COUNTIF(Gabungan!$C$2:$C${n},3)", formulas)
            self.assertIn(f'=COUNTIFS(Gabungan!$E$2:$E${n},">0",Gabungan!$G$2:$G${n},">0")', formulas)  # Vybe & GMGN ranks
            self.assertTrue(any(f.startswith("=SUMPRODUCT(--(LEN(Gabungan!$O$2:$O$") for f in formulas))

    def test_log_sheet_content(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d)
            text = sheet_text(load_workbook(path)["Log"])
            for needle in ("Python", "main.py MINT", "Created output/result.csv", "abc123", "Batas waktu per sumber"):
                self.assertIn(needle, text)

    def test_illegal_characters_and_non_finite_values_do_not_break_saving(self):
        from suite.model import Row
        bad = Row(source="gmgn", wallet="WALLET_Z", rank=9, sheet_row=9, name="bad\x00name\x07", realized=1.0)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "out.xlsx"
            build(path, d, extra_rows={"gmgn": [bad]})
            names = {r[0].value: r[1].value for r in load_workbook(path)["Gabungan"].iter_rows(min_row=2)}
            self.assertEqual(names["WALLET_Z"], "badname")


if __name__ == "__main__":
    unittest.main()
