from __future__ import annotations

import csv
from pathlib import Path

from vybe import Trader


CSV_COLUMNS = ["rank", "trader_address", "name", "labels", "realized_pnl_usd"]


def write_traders_csv(path: Path, traders: list[Trader]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for rank, trader in enumerate(traders, start=1):
            writer.writerow(
                {
                    "rank": rank,
                    "trader_address": trader.trader_address,
                    "name": trader.name or "",
                    "labels": ";".join(trader.labels),
                    "realized_pnl_usd": trader.realized_pnl_usd,
                }
            )
