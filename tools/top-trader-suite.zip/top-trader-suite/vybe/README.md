# Top Trader CLI

Python CLI that fetches the top 100 traders for a Solana token from Vybe (`GET /v4/wallets/top-traders`, available on the Free plan), ranked by realized PnL over the last 1 day, and writes the snapshot to CSV.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export VYBE_API_KEY="your-key"
```

## Run

```bash
python main.py <MINT_ADDRESS>
```

A successful run creates `output/top_traders_<mint>_<UTC timestamp>.csv` with `rank`, `trader_address`, `name`, `labels`, and `realized_pnl_usd`.

Each run makes a fresh request. No database, history, cache, scheduler, or monitoring is used.

## Tests

```bash
python -m unittest discover -v
```

## Error behavior

`400` / `403` fail without retrying (a `403` means the key lacks access to the endpoint). `429` / `500` and network/timeout failures retry up to two times with exponential backoff. A CSV is written only after a successful, valid response.
