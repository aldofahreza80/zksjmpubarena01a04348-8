# Top Trader CLI MVP Specification

- Python CLI: `python main.py <MINT_ADDRESS>`.
- Read `VYBE_API_KEY` from the environment.
- GET `/v4/wallets/top-traders` (Free plan) with `mintAddress={mint}`.
- Use `resolution=1d`, `limit=100`, `page=0`, `sortByDesc=realizedPnlUsd`.
- Use Vybe's `realizedPnlUsd` directly.
- Preserve positive, zero, and negative PnL.
- Export rank, trader address, optional name, optional labels, and realized PnL to CSV.
- Create a fresh timestamped CSV on each successful run under `output/`.
- Retry `429`, `500`, and network/timeout failures up to two retries with exponential backoff.
- Do not retry `400` or `403`.
- Use a 20-second request timeout.
- Never create a CSV after a failed or malformed response.
