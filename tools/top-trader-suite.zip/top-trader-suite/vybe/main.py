from __future__ import annotations
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import sys
from csv_writer import write_traders_csv
from vybe import Trader, VybeClient, VybeError
OUTPUT_DIR = Path("output")
def utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
def safe_mint_for_filename(mint: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", mint)
def fetch_traders(mint: str, api_key: str) -> list[Trader]:
    return VybeClient(api_key).fetch_top_traders(mint)
def run(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Export top token traders by realized PnL from Vybe.")
    parser.add_argument("mint", nargs="?", help="Solana token mint address")
    args = parser.parse_args(argv)
    if not args.mint:
        parser.print_usage(sys.stderr)
        return 2
    api_key = os.environ.get("VYBE_API_KEY")
    if not api_key:
        print("Error: VYBE_API_KEY environment variable is required.", file=sys.stderr)
        return 1
    try:
        traders = fetch_traders(args.mint, api_key)
        if not traders:
            print("Error: Vybe returned no traders for this token.", file=sys.stderr)
            return 1
        output_path = OUTPUT_DIR / f"top_traders_{safe_mint_for_filename(args.mint)}_{utc_timestamp()}.csv"
        write_traders_csv(output_path, traders)
    except (VybeError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Created {output_path} ({len(traders)} traders)")
    return 0
if __name__ == "__main__":
    raise SystemExit(run())
