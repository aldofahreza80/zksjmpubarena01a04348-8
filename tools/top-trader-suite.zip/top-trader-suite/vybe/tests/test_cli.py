from pathlib import Path
import os
import tempfile
import unittest

import main
from vybe import Trader, VybeHttpError


class Environment:
    def __init__(self, key: str, value: str | None):
        self.key = key
        self.value = value
        self.old = os.environ.get(key)

    def __enter__(self):
        if self.value is None:
            os.environ.pop(self.key, None)
        else:
            os.environ[self.key] = self.value

    def __exit__(self, *_args):
        if self.old is None:
            os.environ.pop(self.key, None)
        else:
            os.environ[self.key] = self.old


class CliTests(unittest.TestCase):
    def test_success_creates_timestamped_csv(self):
        with tempfile.TemporaryDirectory() as directory:
            old_dir = main.OUTPUT_DIR
            old_timestamp = main.utc_timestamp
            old_fetch = main.fetch_traders
            main.OUTPUT_DIR = Path(directory)
            main.utc_timestamp = lambda: "20261001_143025"
            main.fetch_traders = lambda _mint, _api_key: [
                Trader("wallet", "Alice", ["KOL"], 42.0)
            ]
            try:
                with Environment("VYBE_API_KEY", "secret"):
                    self.assertEqual(main.run(["mint-123"]), 0)
            finally:
                main.OUTPUT_DIR = old_dir
                main.utc_timestamp = old_timestamp
                main.fetch_traders = old_fetch

            output = Path(directory) / "top_traders_mint-123_20261001_143025.csv"
            self.assertTrue(output.exists())

    def test_api_failure_writes_nothing(self):
        with tempfile.TemporaryDirectory() as directory:
            old_dir = main.OUTPUT_DIR
            old_fetch = main.fetch_traders
            main.OUTPUT_DIR = Path(directory)
            main.fetch_traders = lambda _mint, _api_key: (
                (_ for _ in ()).throw(VybeHttpError(403, "invalid key"))
            )
            try:
                with Environment("VYBE_API_KEY", "secret"):
                    self.assertEqual(main.run(["mint"]), 1)
            finally:
                main.OUTPUT_DIR = old_dir
                main.fetch_traders = old_fetch

            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_missing_key_fails(self):
        with Environment("VYBE_API_KEY", None):
            self.assertEqual(main.run(["mint"]), 1)

    def test_missing_mint_fails(self):
        self.assertEqual(main.run([]), 2)


if __name__ == "__main__":
    unittest.main()
