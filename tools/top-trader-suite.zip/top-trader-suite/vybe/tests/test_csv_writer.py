import csv
from pathlib import Path
import tempfile
import unittest

from csv_writer import write_traders_csv
from vybe import Trader


class CsvWriterTests(unittest.TestCase):
    def test_writes_contract(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "snapshot.csv"
            traders = [
                Trader("wallet-a", "Alice", ["KOL", "Smart Money"], 1234.5),
                Trader("wallet-b", None, [], -2.25),
            ]

            write_traders_csv(output, traders)

            with output.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))

            self.assertEqual(
                rows[0],
                {
                    "rank": "1",
                    "trader_address": "wallet-a",
                    "name": "Alice",
                    "labels": "KOL;Smart Money",
                    "realized_pnl_usd": "1234.5",
                },
            )
            self.assertEqual(rows[1]["realized_pnl_usd"], "-2.25")


if __name__ == "__main__":
    unittest.main()
