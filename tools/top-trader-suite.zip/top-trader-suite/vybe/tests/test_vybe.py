import unittest
import requests
from vybe import VybeClient, VybeHttpError, VybeResponseError
class FakeResponse:
    def __init__(self, status_code, payload): self.status_code, self._payload = status_code, payload
    def json(self): return self._payload
    @property
    def text(self): return str(self._payload)
class FakeSession:
    def __init__(self, responses): self.responses, self.calls = iter(responses), []
    def get(self, url, *, headers, params, timeout):
        self.calls.append((url, headers, params, timeout)); response = next(self.responses)
        if isinstance(response, Exception): raise response
        return response
class VybeClientTests(unittest.TestCase):
    def test_request_config(self):
        s = FakeSession([FakeResponse(200, {"data": [{"traderAddress":"wallet-a","name":"Alice","labels":["KOL"],"realizedPnlUsd":12.5}]})])
        traders = VybeClient("secret", session=s, sleep=lambda _: None).fetch_top_traders("mint-123")
        self.assertEqual(traders[0].trader_address, "wallet-a"); self.assertEqual(traders[0].realized_pnl_usd, 12.5)
        self.assertEqual(s.calls[0][0], "https://api.vybenetwork.xyz/v4/wallets/top-traders")
        self.assertEqual(s.calls[0][2], {"mintAddress":"mint-123","resolution":"1d","limit":100,"page":0,"sortByDesc":"realizedPnlUsd"}); self.assertEqual(s.calls[0][3], 20)
    def test_account_address_field_parsed(self):
        s = FakeSession([FakeResponse(200, {"data": [{"accountAddress":"wallet-z","realizedPnlUsd":"7.25","tradesCount":3,"winRate":50}]})])
        traders = VybeClient("x", session=s, sleep=lambda _: None).fetch_top_traders("m")
        self.assertEqual(traders[0].trader_address, "wallet-z"); self.assertEqual(traders[0].realized_pnl_usd, 7.25)
        self.assertEqual(traders[0].name, None); self.assertEqual(traders[0].labels, [])
    def test_row_without_address_rejected(self):
        s = FakeSession([FakeResponse(200, {"data": [{"realizedPnlUsd": 1, "foo": "bar"}]})])
        with self.assertRaises(VybeResponseError) as e: VybeClient("x", session=s, sleep=lambda _: None).fetch_top_traders("m")
        self.assertIn("foo", str(e.exception))
    def test_nested_metrics_row_from_free_endpoint(self):
        row = {"accountAddress": "3i51cKbL", "accountName": "Bob", "accountLogoUrl": None, "accountTwitterUrl": None, "accountLabels": ["KOL"],
               "metrics": {"realizedPnlUsd": 127.2685161035185, "unrealizedPnlUsd": 103.5, "winRate": 23.07, "tradesVolumeUsd": 2237.5, "tradesCount": 13, "uniqueTokensTraded": None}}
        s = FakeSession([FakeResponse(200, {"data": [row, {**row, "accountAddress": "w2", "accountName": None, "accountLabels": [], "metrics": {"realizedPnlUsd": -3.5}}]})])
        traders = VybeClient("x", session=s, sleep=lambda _: None).fetch_top_traders("m")
        self.assertEqual((traders[0].trader_address, traders[0].name, traders[0].labels, traders[0].realized_pnl_usd), ("3i51cKbL", "Bob", ["KOL"], 127.2685161035185))
        self.assertEqual((traders[1].name, traders[1].labels, traders[1].realized_pnl_usd), (None, [], -3.5))
    def test_invalid_pnl_error_shows_row(self):
        s = FakeSession([FakeResponse(200, {"data": [{"accountAddress": "w", "realizedPnlUsd": None, "pnl": {"x": 1}}]})])
        with self.assertRaises(VybeResponseError) as e: VybeClient("x", session=s, sleep=lambda _: None).fetch_top_traders("m")
        self.assertIn("realizedPnlUsd", str(e.exception)); self.assertIn("pnl", str(e.exception))
    def test_formatted_pnl_string_parsed(self):
        s = FakeSession([FakeResponse(200, {"data": [{"accountAddress": "w", "realizedPnlUsd": "$1,234.50"}]})])
        self.assertEqual(VybeClient("x", session=s, sleep=lambda _: None).fetch_top_traders("m")[0].realized_pnl_usd, 1234.5)
    def test_negative_and_zero_preserved(self):
        s = FakeSession([FakeResponse(200, {"data":[{"traderAddress":"a","realizedPnlUsd":10},{"traderAddress":"b","realizedPnlUsd":0},{"traderAddress":"c","realizedPnlUsd":-4.5}]})])
        self.assertEqual([t.realized_pnl_usd for t in VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")],[10.0,0.0,-4.5])
    def test_400_403_no_retry(self):
        for status in (400,403):
            s=FakeSession([FakeResponse(status,{"message":"bad"})])
            with self.assertRaises(VybeHttpError): VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")
            self.assertEqual(len(s.calls),1)
    def test_429_retries(self):
        s=FakeSession([FakeResponse(429,{"message":"limited"}),FakeResponse(200,{"data":[{"traderAddress":"a","realizedPnlUsd":1}]})])
        self.assertEqual(len(VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")),1); self.assertEqual(len(s.calls),2)
    def test_500_exposes_error_id_after_retries(self):
        s=FakeSession([FakeResponse(500,{"message":"boom","id":"server-123"})]*3)
        with self.assertRaises(VybeHttpError) as e: VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")
        self.assertEqual(e.exception.error_id,"server-123"); self.assertEqual(len(s.calls),3)
    def test_network_error_retries(self):
        s=FakeSession([requests.Timeout("timed out"),FakeResponse(200,{"data":[{"traderAddress":"a","realizedPnlUsd":1}]})])
        self.assertEqual(len(VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")),1)
    def test_malformed_response_rejected(self):
        s=FakeSession([FakeResponse(200,{"unexpected":[]})])
        with self.assertRaises(VybeResponseError): VybeClient("x",session=s,sleep=lambda _:None).fetch_top_traders("m")
if __name__ == "__main__": unittest.main()
