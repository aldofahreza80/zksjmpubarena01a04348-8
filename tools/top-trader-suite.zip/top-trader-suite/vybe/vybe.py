from __future__ import annotations

from dataclasses import dataclass
import json
import time
from typing import Callable, Protocol

import requests

BASE_URL = "https://api.vybenetwork.xyz/v4"
TIMEOUT_SECONDS = 20
MAX_RETRIES = 2
RETRYABLE_STATUS_CODES = {429, 500}
# /wallets/top-traders (free plan) names the wallet field accountAddress; the paid
# /tokens/{mint}/top-pnl-traders endpoint used traderAddress. Accept either.
ADDRESS_KEYS = ("accountAddress", "traderAddress")

@dataclass(frozen=True)
class Trader:
    trader_address: str
    name: str | None
    labels: list[str]
    realized_pnl_usd: float

class Session(Protocol):
    def get(self, url: str, *, headers: dict[str, str], params: dict[str, object], timeout: int): ...

class VybeError(Exception):
    """Base class for errors raised by the Vybe adapter."""

class VybeHttpError(VybeError):
    def __init__(self, status_code: int, message: str, error_id: str | None = None):
        self.status_code = status_code
        self.error_id = error_id
        suffix = f" (error id: {error_id})" if error_id else ""
        super().__init__(f"Vybe API error {status_code}: {message}{suffix}")

class VybeResponseError(VybeError):
    pass

class VybeNetworkError(VybeError):
    pass

class VybeClient:
    def __init__(self, api_key: str, *, session: Session | None = None, sleep: Callable[[float], None] = time.sleep) -> None:
        if not api_key:
            raise ValueError("API key is required")
        self._api_key = api_key
        self._session = session or requests.Session()
        self._sleep = sleep

    def fetch_top_traders(self, mint_address: str) -> list[Trader]:
        if not mint_address.strip():
            raise ValueError("Mint address is required")
        url = f"{BASE_URL}/wallets/top-traders"
        params = {"mintAddress": mint_address.strip(), "resolution": "1d", "limit": 100, "page": 0, "sortByDesc": "realizedPnlUsd"}
        headers = {"X-API-Key": self._api_key, "Accept": "application/json"}
        for attempt in range(MAX_RETRIES + 1):
            try:
                response = self._session.get(url, headers=headers, params=params, timeout=TIMEOUT_SECONDS)
            except requests.RequestException as exc:
                if attempt < MAX_RETRIES:
                    self._sleep(2**attempt)
                    continue
                raise VybeNetworkError(f"Network error contacting Vybe: {exc}") from exc
            if response.status_code == 200:
                return self._parse_traders(response)
            message, error_id = self._error_details(response)
            error = VybeHttpError(response.status_code, message, error_id)
            if response.status_code not in RETRYABLE_STATUS_CODES or attempt >= MAX_RETRIES:
                raise error
            self._sleep(2**attempt)
        raise VybeError("Vybe request failed unexpectedly")

    @staticmethod
    def _error_details(response: object) -> tuple[str, str | None]:
        try:
            payload = response.json()
        except (ValueError, TypeError):
            return getattr(response, "text", "Request failed"), None
        if not isinstance(payload, dict):
            return "Request failed", None
        message = str(payload.get("message") or payload.get("error") or "Request failed")
        error_id = payload.get("id")
        return message, str(error_id) if error_id is not None else None

    @staticmethod
    def _parse_traders(response: object) -> list[Trader]:
        try:
            payload = response.json()
        except (ValueError, TypeError) as exc:
            raise VybeResponseError("Vybe returned invalid JSON") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
            keys = ", ".join(sorted(payload)) if isinstance(payload, dict) else type(payload).__name__
            raise VybeResponseError(f"Vybe response is missing a data array (got: {keys})")
        traders: list[Trader] = []
        for index, item in enumerate(payload["data"], start=1):
            if not isinstance(item, dict):
                raise VybeResponseError(f"Trader row {index} is not an object")
            address = next((item[key] for key in ADDRESS_KEYS if isinstance(item.get(key), str) and item[key]), None)
            if address is None:
                raise VybeResponseError(f"Trader row {index} has no wallet address (row keys: {', '.join(sorted(item))})")
            # Free endpoint nests the numbers under "metrics"; the paid endpoint had them at top level.
            metrics = item.get("metrics") if isinstance(item.get("metrics"), dict) else item
            raw_pnl = metrics.get("realizedPnlUsd", item.get("realizedPnlUsd"))
            try:
                realized_pnl = float(raw_pnl.replace(",", "").lstrip("$") if isinstance(raw_pnl, str) else raw_pnl)
            except (TypeError, ValueError) as exc:
                preview = json.dumps(item, default=str)[:400]
                raise VybeResponseError(f"Trader row {index} has invalid realizedPnlUsd (value: {raw_pnl!r}). Row: {preview}") from exc
            labels = item.get("accountLabels", item.get("labels")) or []
            if not isinstance(labels, list) or not all(isinstance(label, str) for label in labels):
                raise VybeResponseError(f"Trader row {index} has invalid labels")
            name = next((item[key] for key in ("accountName", "name") if isinstance(item.get(key), str) and item[key]), None)
            traders.append(Trader(address, name, labels, realized_pnl))
        return traders
