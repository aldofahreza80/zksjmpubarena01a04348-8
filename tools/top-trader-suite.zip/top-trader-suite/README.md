# top-trader-suite

Satu perintah, tiga sumber, satu file Excel untuk diaudit:

```powershell
python run_all.py <mint>
```

`run_all.py` menjalankan Vybe, Solana Tracker, dan GMGN **secara paralel** untuk mint yang sama (supaya snapshot-nya
berdekatan waktu), lalu menyusun hasilnya berdampingan di satu file Excel. Ketiganya tidak dicampur menjadi satu angka:
setiap provider punya definisi PnL sendiri, dan perbedaan itulah yang diaudit.

## Struktur

```
top-trader-suite/
  run_all.py            skrip utama
  .env                  kunci API (buat dari .env.example; tidak ikut git)
  requirements.txt      requests + openpyxl
  suite/                kode pipeline (runner, adapter, gabungan, Excel)
  vybe/                 CLI Vybe, apa adanya
  solanatracker/        CLI Solana Tracker, apa adanya
  gmgn/                 CLI GMGN, apa adanya
  tests/
  output/
    <mint8>_<waktu>.xlsx        satu-satunya output
    _raw/<mint8>_<waktu>/       arsip: CSV dan JSON asli tiap sumber + run.json
```

Tiga folder provider tidak diubah. Pipeline menjalankan `main.py` masing-masing sebagai proses terpisah, jadi
masing-masing tetap bisa dijalankan sendiri dan kesalahan di lapisan gabungan tidak bisa merusak data sumber.
Nama folder dan file di `output/` memakai 8 karakter pertama mint agar path tidak terlalu panjang di Windows.

## Persiapan

```powershell
pip install -r requirements.txt
copy .env.example .env      # lalu isi tiga kunci
```

`.env` berisi `VYBE_API_KEY`, `SOLANATRACKER_API_KEY`, dan `GMGN_API_KEY` (kunci API GMGN, bukan kunci privat; cara
membuatnya ada di `gmgn/README.md`). Environment variable yang sudah di-set di PowerShell menang atas `.env`.
Setiap proses provider hanya menerima kuncinya sendiri, dan kunci tidak pernah ditulis ke Log atau `run.json`.

## Pemakaian

```powershell
python run_all.py <mint>
python run_all.py <mint> --only vybe,gmgn        # hanya sebagian sumber
python run_all.py <mint> --timeout 60            # batas waktu per sumber (default 120 detik)
python run_all.py <mint> --no-raw                # tanpa arsip JSON mentah dari Solana Tracker/GMGN
python run_all.py <mint> --spread-usd 25 --spread-pct 40   # ambang awal flag_spread
```

Kalau satu sumber gagal (kunci salah, plan tidak cukup, jaringan, timeout), sumber lain tetap jalan dan kegagalannya
tercatat di Ringkasan dan Log. File Excel tidak dibuat hanya jika **semua** sumber gagal; `output/_raw/<run>/run.json` tetap ada.
Sumber tanpa kunci di `.env` dilewati, bukan dijalankan.

## Isi file Excel

| Sheet | Isi |
| --- | --- |
| **Ringkasan** | Status tiap sumber, jumlah baris, waktu mulai/selesai, perkiraan keterlambatan data, cakupan wallet (rumus Excel), kecocokan realized PnL antar pasangan sumber, catatan, kamus kolom. Dua sel kuning berisi ambang `flag_spread` dan boleh diubah. |
| **Gabungan** | Satu baris per wallet: peringkat dan realized PnL tiap sumber berdampingan, `spread_usd`, `spread_pct`, `flag_spread`, `only_in`, `role_disagreement`, label tiap sumber, `funded_by_gmgn`, dan `sheet_row_*` untuk menelusuri ke baris aslinya. |
| **Vybe / SolanaTracker / GMGN** | CSV asli tiap sumber, tanpa perubahan (angka dijadikan angka). Jika sumber gagal, isinya catatan kenapa. |
| **Log** | Perintah persis, folder kerja, waktu, kode keluar, stdout/stderr, versi Python, dan sidik jari (SHA-256) file kode tiap provider. |

`n_sources`, `spread_usd`, `spread_pct`, `flag_spread` dan hitungan di bagian Cakupan adalah **rumus Excel**: klik selnya
untuk melihat cara menghitungnya, atau ubah ambang di Ringkasan dan hasilnya dihitung ulang. Statistik pasangan sumber
(median selisih, korelasi peringkat Spearman, overlap top-10) dihitung oleh skrip Python dan bukan rumus.

## Cara mengaudit

1. **Ringkasan:** apakah ketiga sumber berhasil, jumlah barisnya, dan seberapa tertinggal datanya (kolom selisih ke waktu selesai).
2. **Gabungan:** filter `flag_spread = yes` untuk wallet yang angkanya jauh berbeda, `only_in` untuk wallet yang hanya dilihat satu
   sumber, dan `role_disagreement` untuk perbedaan label (dev, sniper, kol, dan seterusnya).
3. Telusuri angka mana pun lewat `sheet_row_*` ke sheet mentah sumbernya, lalu ke file asli di `output/_raw/<run>/<sumber>/output/`.
4. **Log:** pastikan versi kode dan perintah yang berjalan memang yang kamu maksud.

## Hal yang perlu diingat saat membaca hasilnya

- **Hanya realized PnL yang dibandingkan.** Unrealized bergantung pada harga yang dipakai tiap provider saat menghitung.
- **Daftar maksimal 100 baris per sumber.** Wallet di luar daftar tidak terlihat, jadi `only_in` bisa berarti "terpotong", bukan "tidak ada".
  Ringkasan memberi catatan bila sebuah sumber mencapai batas itu.
- **Keterlambatan data.** Tiap provider mengindeks transaksi dengan jeda berbeda; pada token yang baru berumur menit, ini sering
  jadi sumber selisih terbesar. CSV Vybe tidak punya kolom waktu, jadi keterlambatannya tidak bisa diukur.
- **Vybe belum terverifikasi per token.** Belum pasti apakah `realizedPnlUsd` Vybe dihitung khusus untuk token itu atau seluruh
  aktivitas wallet. Kalau selisihnya besar dan konsisten terhadap dua sumber lain, Ringkasan memberi catatan.
- **GMGN memilih daftarnya berdasarkan `profit`**, lalu dibuat ulang urutannya berdasarkan realized (lihat `gmgn/README.md`).
- Pemetaan label ke peran untuk `role_disagreement` sengaja sederhana dan ada di `suite/labels.py`. Hanya sumber yang memberi label
  pada setidaknya satu wallet di run itu yang dibandingkan.

## Jika gagal

| Gejala | Kemungkinan |
| --- | --- |
| `dilewati` | kunci provider itu tidak ada di `.env` maupun environment |
| `gagal` + `403` | kunci atau plan tidak mencakup endpoint itu (Vybe: plan Free memakai `wallets/top-traders`) |
| GMGN `401/403` padahal kunci benar | GMGN hanya IPv4 dan toleransi jam sekitar 5 detik |
| `timeout` | naikkan `--timeout`, atau cek jaringan |
| `CSV tidak bisa dibaca` | format CSV provider berubah; Log menampilkan kolom yang ada |

## Tes

```powershell
python -m unittest discover -s tests -t .
```

Tes memakai provider palsu dan juga membangkitkan CSV dari `csv_writer.py` asli tiap provider (agar perubahan format CSV
langsung ketahuan). Folder provider punya tes sendiri: `cd vybe; python -m unittest discover`.
