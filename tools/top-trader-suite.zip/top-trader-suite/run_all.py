"""Run the Vybe, Solana Tracker and GMGN modules in parallel for one mint and write ONE audit workbook."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sys

from suite import __version__
from suite.adapters import AdapterError, read_csv_table, rows_from_table
from suite.combine import SourceData, combine
from suite.envfile import load_env_file
from suite.providers import PROVIDERS, ProviderSpec
from suite.runner import RunResult, redact, run_providers, utc_now
from suite.summary import summarize
from suite.workbook import RunInfo, STATUS_TEXT, write_workbook

MINT_PATTERN = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Jalankan Vybe, Solana Tracker dan GMGN secara paralel untuk satu mint, lalu hasilkan satu file Excel untuk audit."
    )
    parser.add_argument("mint", nargs="?", help="alamat mint token Solana")
    parser.add_argument("--only", help="sumber yang dijalankan, dipisah koma: " + ",".join(spec.key for spec in PROVIDERS) + " (default: semuanya)")
    parser.add_argument("--timeout", type=float, default=120, help="batas waktu per sumber dalam detik (default: 120)")
    parser.add_argument("--no-raw", action="store_true", help="jangan minta Solana Tracker/GMGN menyimpan respons mentah (JSON)")
    parser.add_argument("--spread-usd", type=float, default=10.0, help="ambang awal selisih realized dalam USD untuk flag_spread (default: 10)")
    parser.add_argument("--spread-pct", type=float, default=25.0, help="ambang awal selisih relatif dalam persen untuk flag_spread (default: 25)")
    return parser.parse_args(argv)


def fingerprint(provider_dir: Path, spec: ProviderSpec) -> list[tuple[str, str]]:
    out = []
    for name in spec.fingerprint_files:
        path = provider_dir / name
        out.append((name, hashlib.sha256(path.read_bytes()).hexdigest()[:16] if path.is_file() else "tidak ada"))
    return out


def _display(path: Path, root: Path) -> Path:
    try:
        return path.relative_to(root)
    except ValueError:
        return path


def _status_line(result: RunResult, rows: int | None = None) -> str:
    text = STATUS_TEXT.get(result.status, result.status)
    detail = []
    if rows is not None:
        detail.append(f"{rows} baris")
    if result.elapsed is not None:
        detail.append(f"{result.elapsed:.1f} dtk")
    if result.note:
        detail.append(result.note)
    return f"  {result.spec.label:<14} {text}" + (f" ({'; '.join(detail)})" if detail else "")


def _manifest(path: Path, info: RunInfo, results: list[RunResult], row_counts: dict[str, int], adapter_errors: dict[str, str], workbook: Path | None) -> None:
    data = {
        "suite_version": __version__,
        "python": platform.python_version(),
        "mint": info.mint,
        "snapshot_utc": info.snapshot.isoformat(),
        "workbook": str(workbook) if workbook else None,
        "sources": [
            {
                "key": r.spec.key,
                "status": r.status,
                "note": r.note,
                "returncode": r.returncode,
                "command": r.command,
                "cwd": str(r.cwd) if r.cwd else None,
                "started_utc": r.started.isoformat() if r.started else None,
                "ended_utc": r.ended.isoformat() if r.ended else None,
                "csv": str(r.csv_path) if r.csv_path else None,
                "rows": row_counts.get(r.spec.key),
                "adapter_error": adapter_errors.get(r.spec.key),
            }
            for r in results
        ],
    }
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def run(argv: list[str] | None = None, *, root: Path | None = None, providers: tuple[ProviderSpec, ...] = PROVIDERS, python: str | None = None) -> int:
    args = parse_args(argv)
    if not args.mint:
        print("Pemakaian: python run_all.py <mint> [--only vybe,gmgn] [--timeout 120]", file=sys.stderr)
        return 2
    mint = args.mint.strip()
    if not MINT_PATTERN.match(mint):
        print("Error: mint bukan alamat Solana yang valid.", file=sys.stderr)
        return 1
    selected = list(providers)
    if args.only:
        wanted = [part.strip().lower() for part in args.only.split(",") if part.strip()]
        unknown = [name for name in wanted if name not in {spec.key for spec in providers}]
        if unknown or not wanted:
            print(f"Error: sumber tidak dikenal: {', '.join(unknown) or '(kosong)'}. Pilihan: {', '.join(spec.key for spec in providers)}", file=sys.stderr)
            return 2
        selected = [spec for spec in providers if spec.key in wanted]
    if args.spread_usd < 0 or args.spread_pct < 0:
        print("Error: ambang selisih tidak boleh negatif.", file=sys.stderr)
        return 2

    root = Path(root) if root else Path(__file__).resolve().parent
    dotenv = load_env_file(root / ".env")
    all_env_vars = [spec.env_var for spec in providers]
    keys = {var: os.environ.get(var) or dotenv.get(var, "") for var in all_env_vars}
    keys = {var: value for var, value in keys.items() if value}

    snapshot = utc_now()
    run_id = f"{mint[:8]}_{snapshot:%Y%m%d_%H%M%S}"
    work_dir = root / "output" / "_raw" / run_id
    workbook_path = root / "output" / f"{run_id}.xlsx"
    work_dir.mkdir(parents=True, exist_ok=True)
    info = RunInfo(
        mint=mint, snapshot=snapshot, spread_usd=args.spread_usd, spread_pct=args.spread_pct / 100.0,
        timeout=args.timeout, raw_json=not args.no_raw, requested=[spec.label for spec in selected],
    )

    print(f"Menjalankan {', '.join(info.requested)} secara paralel untuk {mint} ...")
    results = run_providers(
        selected, root=root, mint=mint, work_dir=work_dir, keys=keys, all_env_vars=all_env_vars, timeout=args.timeout,
        raw_json=not args.no_raw, python=python, on_done=lambda r: print(_status_line(r)),
    )

    sources: list[SourceData] = []
    tables: dict[str, tuple[list[str], list[list[str]]]] = {}
    adapter_errors: dict[str, str] = {}
    row_counts: dict[str, int] = {}
    for result in results:
        if result.status != "ok" or result.csv_path is None:
            continue
        try:
            header, table = read_csv_table(result.csv_path)
            rows, warnings = rows_from_table(result.spec.key, header, table)
            if not rows:
                raise AdapterError("CSV tidak berisi wallet")
        except (AdapterError, OSError, UnicodeDecodeError) as exc:
            result.status, result.note = "failed", redact(f"CSV tidak bisa dibaca: {exc}", [v for v in keys.values()])
            adapter_errors[result.spec.key] = result.note
            print(f"  {result.spec.label:<14} gagal ({result.note})", file=sys.stderr)
            continue
        sources.append(SourceData(key=result.spec.key, label=result.spec.label, rows=rows, warnings=warnings))
        tables[result.spec.key] = (header, table)
        row_counts[result.spec.key] = len(rows)

    if not sources:
        _manifest(work_dir / "run.json", info, results, row_counts, adapter_errors, None)
        print("Tidak ada sumber yang berhasil, jadi file Excel tidak dibuat. Detail ada di " + str(work_dir / "run.json"), file=sys.stderr)
        for result in results:
            if result.status != "ok":
                print(f"  {result.spec.label}: {result.note or STATUS_TEXT.get(result.status, result.status)}", file=sys.stderr)
        return 1

    combined = combine(sources, spread_pct=info.spread_pct, spread_usd=info.spread_usd)
    summary = summarize(sources, snapshot)
    fingerprints = {spec.key: fingerprint(root / spec.folder, spec) for spec in providers}
    try:
        write_workbook(
            workbook_path, info=info, specs=list(providers), results=results, sources=sources, tables=tables,
            combined=combined, summary=summary, fingerprints=fingerprints,
        )
    except Exception as exc:  # the raw per-provider files stay valid even if the combined file cannot be written
        _manifest(work_dir / "run.json", info, results, row_counts, adapter_errors, None)
        print(f"Error: gagal menulis file Excel: {exc}. Hasil mentah tetap ada di {work_dir}", file=sys.stderr)
        return 1
    _manifest(work_dir / "run.json", info, results, row_counts, adapter_errors, workbook_path)
    failed = [r for r in results if r.status != "ok"]
    print(f"Dibuat {_display(workbook_path, root)} ({len(combined)} wallet unik dari {len(sources)} sumber)"
          + (f"; {len(failed)} sumber tidak ikut" if failed else ""))
    print(f"Arsip mentah: {work_dir}")
    return 0


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):  # never crash while printing odd characters from provider messages
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    raise SystemExit(run())
